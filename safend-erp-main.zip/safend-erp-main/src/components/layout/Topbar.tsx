import { useTheme } from "@/components/ThemeProvider";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { LogOut, Settings, User, Sun, Moon, Building2 } from "lucide-react";
import { NotificationPanel } from "./NotificationPanel";
import { DigitalClock } from "./DigitalClock";
import { DrawerNavigation } from "./DrawerNavigation";
import { motion } from "framer-motion";
import { toast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { Branch } from "@/types/branch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
export function Topbar() {
  const {
    theme,
    setTheme
  } = useTheme();
  const [branches, setBranches] = useState<Branch[]>([]);
  const [selectedBranchId, setSelectedBranchId] = useState<string>("main");
  const [isLoading, setIsLoading] = useState(false);
  useEffect(() => {
    // In a real app, this would fetch from an API
    const storedBranches = localStorage.getItem("branches");
    const initialBranches: Branch[] = storedBranches ? JSON.parse(storedBranches) : [{
      id: "main",
      name: "Main Branch (HQ)",
      code: "HQ-001",
      address: "123 Main Street",
      city: "Delhi",
      state: "Delhi",
      country: "India",
      postalCode: "110001",
      phone: "+91 11-12345678",
      email: "hq@safend.com",
      managerName: "Rahul Sharma",
      managerId: "u1",
      status: "active",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }];
    setBranches(initialBranches);

    // Get selected branch from localStorage or use main branch
    const storedBranchId = localStorage.getItem("selectedBranchId");
    if (storedBranchId) {
      setSelectedBranchId(storedBranchId);
    }
  }, []);
  const handleBranchChange = (value: string) => {
    setIsLoading(true);
    setSelectedBranchId(value);
    localStorage.setItem("selectedBranchId", value);

    // Simulate a brief loading period
    setTimeout(() => {
      setIsLoading(false);
      toast.success({
        title: `Switched to ${branches.find(b => b.id === value)?.name || "Main Branch"}`,
        position: "bottom-right",
        duration: 2000
      });

      // If we're on a page that needs branch data, trigger a refresh
      // In a real app, this would use a context or state management
      if (window.location.pathname.includes("control-centre")) {
        window.dispatchEvent(new CustomEvent("branch-changed", {
          detail: value
        }));
      }
    }, 500);
  };
  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    toast.success({
      title: `Switched to ${newTheme} theme`,
      position: "bottom-right",
      duration: 2000
    });
  };
  return <motion.header className="sticky top-0 z-40 w-full backdrop-blur-xl border-b border-white/10 dark:border-black/10 bg-white/90 dark:bg-black/90 shadow-sm transition-colors duration-300" initial={{
    y: -20,
    opacity: 0
  }} animate={{
    y: 0,
    opacity: 1
  }} transition={{
    duration: 0.5,
    ease: [0.16, 1, 0.3, 1]
  }}>
      <div className="flex items-center justify-between h-16 px-4 md:px-6">
        <div className="flex items-center gap-3">
          <DrawerNavigation />
          
          <motion.div className="flex items-center gap-2" whileHover={{
          scale: 1.05
        }} transition={{
          duration: 0.3
        }}>
            <div className="w-10 h-10 bg-gradient-to-r from-red-600 to-black rounded-xl flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-lg">S</span>
            </div>
            <span className="font-bold hidden sm:inline-block bg-gradient-to-r from-red-600 to-black bg-clip-text text-xl text-red-600">Safend Control Room</span>
          </motion.div>
        </div>

        <div className="flex items-center gap-4">
          <Select value={selectedBranchId} onValueChange={handleBranchChange}>
            <SelectTrigger className="w-[180px] md:w-[220px] h-9 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-900 dark:to-black border border-gray-200 dark:border-gray-800 flex items-center gap-2 rounded-xl shadow-sm">
              <Building2 className="h-4 w-4 text-safend-red flex-shrink-0" />
              <SelectValue placeholder="Select branch" />
            </SelectTrigger>
            <SelectContent className="animate-tilt-in rounded-xl bg-white/90 dark:bg-black/90 backdrop-blur-xl border border-gray-200 dark:border-gray-800">
              {branches.map(branch => <SelectItem key={branch.id} value={branch.id} className={branch.id === "main" ? "font-bold" : ""}>
                  {branch.name} {branch.id === "main" ? "(Master)" : ""}
                </SelectItem>)}
            </SelectContent>
          </Select>
          
          <DigitalClock />
          <NotificationPanel />

          <motion.button whileTap={{
          scale: 0.9
        }} onClick={toggleTheme} className="flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-900 dark:to-black border border-gray-200 dark:border-gray-800 shadow-sm">
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </motion.button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                <Avatar className="h-10 w-10 border-2 border-safend-red hover:scale-110 transition-transform duration-300 cursor-pointer">
                  <AvatarImage src="/placeholder.svg" alt="User avatar" />
                  <AvatarFallback>AD</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 animate-tilt-in rounded-xl bg-white/90 dark:bg-black/90 backdrop-blur-xl border border-gray-200 dark:border-gray-800">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="cursor-pointer">
                <User className="mr-2 h-4 w-4" />
                <span>Switch Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer">
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="cursor-pointer text-safend-red focus:text-safend-red">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </motion.header>;
}