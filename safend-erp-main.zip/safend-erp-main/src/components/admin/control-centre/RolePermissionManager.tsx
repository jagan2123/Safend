
import { useState } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Plus, Search, Edit, Trash2, Save, Shield } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { RoleEditForm } from "./forms/RoleEditForm";
import { RoleAssignmentForm, RoleAssignmentData } from "./forms/RoleAssignmentForm";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Role {
  id: string;
  name: string;
  description: string;
  userCount: number;
  status: "active" | "inactive";
}

export function RolePermissionManager() {
  const [activeTab, setActiveTab] = useState("roles");
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  
  // Role form state
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [isAddingRole, setIsAddingRole] = useState(false);
  const [isRoleDialogOpen, setIsRoleDialogOpen] = useState(false);
  const [roleToDelete, setRoleToDelete] = useState<string | null>(null);
  
  // Role assignment state
  const [isAssignmentFormOpen, setIsAssignmentFormOpen] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<RoleAssignmentData | null>(null);
  const [roleAssignments, setRoleAssignments] = useState<RoleAssignmentData[]>([
    {
      id: "ra1",
      userId: "u1",
      userName: "Rahul Sharma",
      branchId: "b1",
      branchName: "Mumbai HQ",
      roles: ["r1", "r5"],
      assignedBy: "System",
      assignedDate: "2025-05-03T00:00:00Z"
    },
    {
      id: "ra2",
      userId: "u2",
      userName: "Priya Patel",
      branchId: "b1",
      branchName: "Mumbai HQ",
      roles: ["r2"],
      assignedBy: "Rahul Sharma",
      assignedDate: "2025-05-02T00:00:00Z"
    },
    {
      id: "ra3",
      userId: "u3",
      userName: "Amit Singh",
      branchId: "b3",
      branchName: "Bangalore Office",
      roles: ["r1"],
      assignedBy: "Rahul Sharma",
      assignedDate: "2025-04-28T00:00:00Z"
    }
  ]);
  
  // Permission matrix state
  const [selectedRoleForPermissions, setSelectedRoleForPermissions] = useState<string>("r1");
  const [unsavedChanges, setUnsavedChanges] = useState(false);
  
  // Mock role data
  const [roles, setRoles] = useState<Role[]>([
    { 
      id: "r1", 
      name: "Branch Admin", 
      description: "Full control over branch operations",
      userCount: 2,
      status: "active"
    },
    { 
      id: "r2", 
      name: "HR Manager", 
      description: "Full access to HR module",
      userCount: 3,
      status: "active"
    },
    { 
      id: "r3", 
      name: "Sales Executive", 
      description: "Sales module with limited rights",
      userCount: 5,
      status: "active"
    }
  ]);
  
  // Filter roles based on search term
  const filteredRoles = searchTerm 
    ? roles.filter(role => 
        role.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        role.description.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : roles;
  
  // Modules for permission matrix
  const modules = ["Control Centre", "Sales", "Operations", "Accounts", "HR", "Office Admin", "Reports"];
  
  // Operations for permission matrix
  const operations = ["View", "Create", "Edit", "Delete", "Export", "Approve"];
  
  // Permission matrix state - initialized with some permissions for Branch Admin
  const [permissionMatrix, setPermissionMatrix] = useState<Record<string, Record<string, boolean>>>({
    "Control Centre": { "View": true, "Create": true, "Edit": false, "Delete": false, "Export": true, "Approve": false },
    "Sales": { "View": true, "Create": false, "Edit": false, "Delete": false, "Export": true, "Approve": false },
    "Operations": { "View": true, "Create": false, "Edit": false, "Delete": false, "Export": true, "Approve": false },
    "Accounts": { "View": false, "Create": false, "Edit": false, "Delete": false, "Export": false, "Approve": false },
    "HR": { "View": false, "Create": false, "Edit": false, "Delete": false, "Export": false, "Approve": false },
    "Office Admin": { "View": false, "Create": false, "Edit": false, "Delete": false, "Export": false, "Approve": false },
    "Reports": { "View": true, "Create": false, "Edit": false, "Delete": false, "Export": true, "Approve": false },
  });
  
  const handleEditRole = (role: Role) => {
    setSelectedRole(role);
    setIsAddingRole(false);
    setIsRoleDialogOpen(true);
  };
  
  const handleDeleteRole = (roleId: string) => {
    setRoleToDelete(roleId);
  };
  
  const confirmDeleteRole = () => {
    if (!roleToDelete) return;
    
    const updatedRoles = roles.filter(r => r.id !== roleToDelete);
    setRoles(updatedRoles);
    
    toast({
      title: "Role Deleted",
      description: "Role has been removed from the system",
    });
    
    setRoleToDelete(null);
  };
  
  const handleAddRole = () => {
    setSelectedRole(null);
    setIsAddingRole(true);
    setIsRoleDialogOpen(true);
  };
  
  const handleSaveRole = (roleData: Partial<Role>) => {
    if (isAddingRole) {
      // Generate a unique ID for the new role
      const newId = `r${roles.length + 1}`;
      
      const newRole: Role = {
        id: newId,
        name: roleData.name || '',
        description: roleData.description || '',
        userCount: 0,
        status: roleData.status as "active" | "inactive" || "active"
      };
      
      setRoles([...roles, newRole]);
      
      toast({
        title: "Role Created",
        description: `${newRole.name} has been created successfully`,
      });
    } else if (selectedRole) {
      // Update existing role
      const updatedRoles = roles.map(r => {
        if (r.id === selectedRole.id) {
          return {
            ...r,
            ...roleData,
          };
        }
        return r;
      });
      
      setRoles(updatedRoles);
      
      toast({
        title: "Role Updated",
        description: `${roleData.name} has been updated successfully`,
      });
    }
    
    setIsRoleDialogOpen(false);
    setIsAddingRole(false);
    setSelectedRole(null);
  };
  
  const handlePermissionChange = (module: string, operation: string, checked: boolean) => {
    setPermissionMatrix(prev => ({
      ...prev,
      [module]: {
        ...prev[module],
        [operation]: checked
      }
    }));
    
    setUnsavedChanges(true);
  };
  
  const handleApplyPermissionChanges = () => {
    // In a real app, this would call an API to update permissions
    toast({
      title: "Permissions Updated",
      description: "Role permissions have been updated in the system",
    });
    
    setUnsavedChanges(false);
  };

  // Role assignment handlers
  const handleAddAssignment = () => {
    setSelectedAssignment(null);
    setIsAssignmentFormOpen(true);
  };

  const handleEditAssignment = (assignment: RoleAssignmentData) => {
    setSelectedAssignment(assignment);
    setIsAssignmentFormOpen(true);
  };

  const handleSaveAssignment = (assignmentData: RoleAssignmentData) => {
    if (selectedAssignment) {
      // Update existing assignment
      setRoleAssignments(prev => 
        prev.map(item => 
          item.id === selectedAssignment.id 
            ? { ...assignmentData, id: item.id } 
            : item
        )
      );
    } else {
      // Create new assignment
      const newId = `ra${roleAssignments.length + 1}`;
      setRoleAssignments(prev => [
        ...prev, 
        { ...assignmentData, id: newId }
      ]);
    }

    setIsAssignmentFormOpen(false);
    setSelectedAssignment(null);
  };
  
  const selectedRoleForMatrix = roles.find(r => r.id === selectedRoleForPermissions) || roles[0];

  // Helper to render role names instead of IDs in assignment table
  const getRoleNames = (roleIds: string[]) => {
    return roleIds.map(id => {
      const role = roles.find(r => r.id === id);
      return role ? role.name : id;
    });
  };

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full grid grid-cols-3">
          <TabsTrigger value="roles">Roles</TabsTrigger>
          <TabsTrigger value="permissions">Permission Matrix</TabsTrigger>
          <TabsTrigger value="assignments">Role Assignments</TabsTrigger>
        </TabsList>
        
        <TabsContent value="roles" className="space-y-6 mt-6">
          <Card className="control-centre-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle className="text-xl font-bold">Role Management</CardTitle>
                <CardDescription>
                  Create and manage roles with specific permissions
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search roles..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 w-[200px]"
                  />
                </div>
                <Button variant="destructive" className="gap-2" onClick={handleAddRole}>
                  <Plus className="h-4 w-4" />
                  Add Role
                </Button>
              </div>
            </CardHeader>
            
            <CardContent>
              <ScrollArea className="h-[400px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Role Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Users</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRoles.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-6 text-muted-foreground">
                          No roles found matching your criteria
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredRoles.map(role => (
                        <TableRow key={role.id}>
                          <TableCell className="font-medium">{role.name}</TableCell>
                          <TableCell>{role.description}</TableCell>
                          <TableCell>{role.userCount}</TableCell>
                          <TableCell>
                            <Badge variant={role.status === "active" ? "default" : "secondary"}>
                              {role.status === "active" ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right space-x-2">
                            <Button variant="ghost" size="icon" onClick={() => handleEditRole(role)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="text-red-600"
                              onClick={() => handleDeleteRole(role.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="permissions" className="mt-6">
          <Card className="control-centre-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle className="text-xl font-bold">Permission Matrix</CardTitle>
                <CardDescription>
                  Define fine-grained permissions for each role
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <select 
                  className="p-2 border rounded-md" 
                  value={selectedRoleForPermissions}
                  onChange={(e) => setSelectedRoleForPermissions(e.target.value)}
                >
                  {roles.map(role => (
                    <option key={role.id} value={role.id}>{role.name}</option>
                  ))}
                </select>
                <Button 
                  variant="default" 
                  className="gap-2"
                  onClick={handleApplyPermissionChanges}
                  disabled={!unsavedChanges}
                >
                  <Save className="h-4 w-4" />
                  Save Changes
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="overflow-x-auto">
              <ScrollArea className="h-[400px]">
                <table className="permission-matrix w-full">
                  <thead>
                    <tr>
                      <th className="text-left p-3 border-b">Module / Action</th>
                      {operations.map(op => (
                        <th key={op} className="text-center p-3 border-b">{op}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {modules.map(module => (
                      <tr key={module} className="border-b">
                        <td className="text-left p-3 font-medium">{module}</td>
                        {operations.map(op => (
                          <td key={`${module}-${op}`} className="text-center p-3">
                            <Switch 
                              checked={permissionMatrix[module]?.[op] || false}
                              onCheckedChange={(checked) => handlePermissionChange(module, op, checked)}
                            />
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </ScrollArea>
            </CardContent>
            <CardFooter className="border-t p-4 flex justify-between">
              <div className="flex items-center">
                <Shield className="h-5 w-5 text-red-600 mr-2" />
                <span className="text-sm text-muted-foreground">
                  Casbin policy will be updated in real-time
                </span>
              </div>
              <Button 
                variant="default"
                onClick={handleApplyPermissionChanges}
                disabled={!unsavedChanges}
              >
                Apply Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="assignments" className="mt-6">
          <Card className="control-centre-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle className="text-xl font-bold">Role Assignments</CardTitle>
                <CardDescription>
                  Assign roles to users across different branches
                </CardDescription>
              </div>
              <Button variant="destructive" className="gap-2" onClick={handleAddAssignment}>
                <Plus className="h-4 w-4" />
                New Assignment
              </Button>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Branch</TableHead>
                      <TableHead>Assigned Roles</TableHead>
                      <TableHead>Assigned By</TableHead>
                      <TableHead>Date Assigned</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {roleAssignments.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-6 text-muted-foreground">
                          No role assignments found
                        </TableCell>
                      </TableRow>
                    ) : (
                      roleAssignments.map(assignment => (
                        <TableRow key={assignment.id}>
                          <TableCell className="font-medium">{assignment.userName}</TableCell>
                          <TableCell>{assignment.branchName}</TableCell>
                          <TableCell>
                            <div className="flex gap-1 flex-wrap">
                              {assignment.roles.map((roleId, index) => {
                                const roleName = getRoleNames([roleId])[0];
                                return (
                                  <Badge
                                    key={`${assignment.id}-${roleId}`}
                                    className={index === 0 ? "bg-black text-white" : "bg-red-600 text-white"}
                                  >
                                    {roleName}
                                  </Badge>
                                );
                              })}
                            </div>
                          </TableCell>
                          <TableCell>{assignment.assignedBy}</TableCell>
                          <TableCell>
                            {new Date(assignment.assignedDate || "").toLocaleDateString()}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="gap-1"
                              onClick={() => handleEditAssignment(assignment)}
                            >
                              <Edit className="h-3 w-3" />
                              Edit
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Role Edit Form */}
      <RoleEditForm
        role={selectedRole}
        isOpen={isRoleDialogOpen}
        onClose={() => {
          setIsRoleDialogOpen(false);
          setIsAddingRole(false);
          setSelectedRole(null);
        }}
        onSave={handleSaveRole}
        isNew={isAddingRole}
      />
      
      {/* Role Assignment Form */}
      <RoleAssignmentForm
        isOpen={isAssignmentFormOpen}
        onClose={() => {
          setIsAssignmentFormOpen(false);
          setSelectedAssignment(null);
        }}
        onSave={handleSaveAssignment}
        existingAssignment={selectedAssignment}
      />
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!roleToDelete} onOpenChange={() => setRoleToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the 
              role and may affect users who have been assigned this role.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-red-600 text-white hover:bg-red-700"
              onClick={confirmDeleteRole}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
