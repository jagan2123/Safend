
import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Activity, RefreshCw, ArrowUpRight, Database, Server, AlertTriangle, CheckCircle2 } from "lucide-react";

export function HealthMetrics() {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  
  // Update last updated time on mount
  useEffect(() => {
    setLastUpdated(new Date());
  }, []);
  
  const handleRefresh = () => {
    setIsRefreshing(true);
    
    // Simulate API fetch
    setTimeout(() => {
      setIsRefreshing(false);
      setLastUpdated(new Date());
    }, 1000);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">System Health & Metrics</h2>
          <p className="text-muted-foreground">
            {lastUpdated ? (
              <>Last updated: {lastUpdated.toLocaleTimeString()}</>
            ) : (
              <>Loading health metrics...</>
            )}
          </p>
        </div>
        <Button variant="outline" onClick={handleRefresh} disabled={isRefreshing} className="gap-2">
          <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="control-centre-card">
          <CardContent className="p-6 flex flex-col items-center justify-center text-center">
            <div className="rounded-full bg-green-100 p-3 mb-4">
              <Server className="h-6 w-6 text-green-600" />
            </div>
            <CardTitle className="text-lg mb-1">API Health</CardTitle>
            <div className="text-2xl font-bold text-green-600">100%</div>
            <p className="text-sm text-muted-foreground">All systems operational</p>
          </CardContent>
        </Card>
        
        <Card className="control-centre-card">
          <CardContent className="p-6 flex flex-col items-center justify-center text-center">
            <div className="rounded-full bg-blue-100 p-3 mb-4">
              <Database className="h-6 w-6 text-blue-600" />
            </div>
            <CardTitle className="text-lg mb-1">Database</CardTitle>
            <div className="text-2xl font-bold text-blue-600">95.2%</div>
            <p className="text-sm text-muted-foreground">Query performance</p>
          </CardContent>
        </Card>
        
        <Card className="control-centre-card">
          <CardContent className="p-6 flex flex-col items-center justify-center text-center">
            <div className="rounded-full bg-amber-100 p-3 mb-4">
              <Activity className="h-6 w-6 text-amber-600" />
            </div>
            <CardTitle className="text-lg mb-1">Response Time</CardTitle>
            <div className="text-2xl font-bold text-amber-600">256ms</div>
            <p className="text-sm text-muted-foreground">Average response time</p>
          </CardContent>
        </Card>
        
        <Card className="control-centre-card">
          <CardContent className="p-6 flex flex-col items-center justify-center text-center">
            <div className="rounded-full bg-violet-100 p-3 mb-4">
              <ArrowUpRight className="h-6 w-6 text-violet-600" />
            </div>
            <CardTitle className="text-lg mb-1">Uptime</CardTitle>
            <div className="text-2xl font-bold text-violet-600">99.98%</div>
            <p className="text-sm text-muted-foreground">Last 30 days</p>
          </CardContent>
        </Card>
      </div>
      
      <Card className="control-centre-card">
        <CardHeader>
          <CardTitle className="text-xl font-bold">Health Check Status</CardTitle>
          <CardDescription>
            Live status of system components and services
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 border-b">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium">API Gateway</p>
                  <p className="text-sm text-muted-foreground">Accepting connections</p>
                </div>
              </div>
              <Badge className="bg-green-600 text-white">Healthy</Badge>
            </div>
            
            <div className="flex justify-between items-center p-3 border-b">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium">NestJS Services</p>
                  <p className="text-sm text-muted-foreground">All services running</p>
                </div>
              </div>
              <Badge className="bg-green-600 text-white">Healthy</Badge>
            </div>
            
            <div className="flex justify-between items-center p-3 border-b">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium">PostgreSQL Database</p>
                  <p className="text-sm text-muted-foreground">Connected</p>
                </div>
              </div>
              <Badge className="bg-green-600 text-white">Healthy</Badge>
            </div>
            
            <div className="flex justify-between items-center p-3 border-b">
              <div className="flex items-center gap-3">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
                <div>
                  <p className="font-medium">Redis Cache</p>
                  <p className="text-sm text-muted-foreground">High memory usage</p>
                </div>
              </div>
              <Badge className="bg-amber-500 text-white">Warning</Badge>
            </div>
            
            <div className="flex justify-between items-center p-3 border-b">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium">BullMQ Jobs</p>
                  <p className="text-sm text-muted-foreground">Processing normally</p>
                </div>
              </div>
              <Badge className="bg-green-600 text-white">Healthy</Badge>
            </div>
            
            <div className="flex justify-between items-center p-3">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium">Keycloak Auth</p>
                  <p className="text-sm text-muted-foreground">Accessible</p>
                </div>
              </div>
              <Badge className="bg-green-600 text-white">Healthy</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="control-centre-card">
        <CardHeader>
          <CardTitle className="text-xl font-bold">Prometheus Metrics</CardTitle>
          <CardDescription>
            Real-time performance and resource usage metrics
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-60 w-full bg-gray-100 dark:bg-gray-900 rounded-lg flex items-center justify-center">
            <p className="text-muted-foreground">Prometheus metrics visualization will appear here</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            <div className="space-y-2">
              <h3 className="font-medium">API Request Rate</h3>
              <div className="w-full h-2 bg-gray-200 dark:bg-gray-800 rounded-full">
                <div className="h-2 bg-gradient-to-r from-red-600 to-black rounded-full" style={{ width: '75%' }}></div>
              </div>
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>0</span>
                <span>75 req/s</span>
                <span>100 req/s</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <h3 className="font-medium">CPU Usage</h3>
              <div className="w-full h-2 bg-gray-200 dark:bg-gray-800 rounded-full">
                <div className="h-2 bg-gradient-to-r from-red-600 to-black rounded-full" style={{ width: '45%' }}></div>
              </div>
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>0%</span>
                <span>45%</span>
                <span>100%</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <h3 className="font-medium">Memory Usage</h3>
              <div className="w-full h-2 bg-gray-200 dark:bg-gray-800 rounded-full">
                <div className="h-2 bg-gradient-to-r from-red-600 to-black rounded-full" style={{ width: '62%' }}></div>
              </div>
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>0GB</span>
                <span>4.96GB / 8GB</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <h3 className="font-medium">Disk I/O</h3>
              <div className="w-full h-2 bg-gray-200 dark:bg-gray-800 rounded-full">
                <div className="h-2 bg-gradient-to-r from-red-600 to-black rounded-full" style={{ width: '30%' }}></div>
              </div>
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>0 MB/s</span>
                <span>12 MB/s</span>
                <span>40 MB/s</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
