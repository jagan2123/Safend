
import { useState } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Download, FileType, ChevronDown, ChevronLeft, ChevronRight, Calendar, Filter } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export function ActivityAudit() {
  const [dateFilter, setDateFilter] = useState("all-time");
  const [moduleFilter, setModuleFilter] = useState("all");
  const [page, setPage] = useState(1);
  
  // Mock activity data
  const activities = [
    { id: 1, user: "Rahul Sharma", action: "User Created", target: "Priya Patel", module: "User Manager", timestamp: "2025-05-06 09:45:12", ip: "192.168.1.10" },
    { id: 2, user: "Rahul Sharma", action: "Role Assigned", target: "HR Manager", module: "Role Manager", timestamp: "2025-05-06 09:46:30", ip: "192.168.1.10" },
    { id: 3, user: "Priya Patel", action: "Logged In", target: "System", module: "Authentication", timestamp: "2025-05-06 10:15:22", ip: "192.168.1.15" },
    { id: 4, user: "System", action: "Backup Completed", target: "Database", module: "Maintenance", timestamp: "2025-05-06 02:00:05", ip: "localhost" },
    { id: 5, user: "Amit Singh", action: "Branch Updated", target: "Bangalore Office", module: "Branch Manager", timestamp: "2025-05-05 16:30:45", ip: "192.168.1.20" },
  ];
  
  return (
    <div className="space-y-6">
      <Card className="control-centre-card">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle className="text-xl font-bold">Activity & Audit Log</CardTitle>
            <CardDescription>
              Immutable record of all system activity and user actions
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <Calendar className="h-4 w-4" />
                  {dateFilter === "all-time" ? "All Time" : 
                   dateFilter === "today" ? "Today" : 
                   dateFilter === "this-week" ? "This Week" :
                   "This Month"}
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setDateFilter("all-time")}>All Time</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setDateFilter("today")}>Today</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setDateFilter("this-week")}>This Week</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setDateFilter("this-month")}>This Month</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <Filter className="h-4 w-4" />
                  {moduleFilter === "all" ? "All Modules" : moduleFilter}
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setModuleFilter("all")}>All Modules</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setModuleFilter("User Manager")}>User Manager</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setModuleFilter("Role Manager")}>Role Manager</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setModuleFilter("Branch Manager")}>Branch Manager</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setModuleFilter("Authentication")}>Authentication</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <FileType className="h-4 w-4" />
                  Export
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem className="gap-2">
                  <Download className="h-4 w-4" />
                  Export as CSV
                </DropdownMenuItem>
                <DropdownMenuItem className="gap-2">
                  <Download className="h-4 w-4" />
                  Export as PDF
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
        
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Timestamp</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Target</TableHead>
                <TableHead>Module</TableHead>
                <TableHead>IP Address</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {activities.map(activity => (
                <TableRow key={activity.id}>
                  <TableCell className="font-mono text-xs">{activity.timestamp}</TableCell>
                  <TableCell>{activity.user}</TableCell>
                  <TableCell>{activity.action}</TableCell>
                  <TableCell>{activity.target}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="bg-black text-white">
                      {activity.module}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-mono">{activity.ip}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          <div className="flex items-center justify-between mt-4">
            <p className="text-sm text-muted-foreground">
              Showing 5 of 243 activities
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="icon" disabled={page === 1} onClick={() => setPage(page - 1)}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm">1</Button>
              <Button variant="outline" size="sm">2</Button>
              <Button variant="outline" size="icon" onClick={() => setPage(page + 1)}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="control-centre-card">
        <CardHeader>
          <CardTitle className="text-xl font-bold">Activity Analytics</CardTitle>
          <CardDescription>
            Visual representation of system activity over time
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center p-6">
          <div className="h-60 w-full bg-gray-100 dark:bg-gray-900 rounded-lg flex items-center justify-center">
            <p className="text-muted-foreground">ApexCharts integration will appear here</p>
          </div>
          <div className="flex gap-3 mt-6">
            <Badge className="bg-black text-white">User Logins</Badge>
            <Badge className="bg-red-600 text-white">Role Changes</Badge>
            <Badge className="bg-gray-500 text-white">Branch Operations</Badge>
            <Badge className="bg-blue-500 text-white">System Events</Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
