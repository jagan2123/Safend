
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Progress } from "@/components/ui/progress";

interface LoadingAnimationProps {
  size?: "sm" | "md" | "lg";
  color?: "primary" | "red" | "white";
  showPercentage?: boolean;
  percentageValue?: number;
  className?: string;
}

export function LoadingAnimation({ 
  size = "md", 
  color = "primary",
  showPercentage = false,
  percentageValue,
  className
}: LoadingAnimationProps) {
  const [percentage, setPercentage] = useState(percentageValue || 0);
  
  // Auto-increment percentage if not provided externally
  useEffect(() => {
    if (showPercentage && percentageValue === undefined) {
      const interval = setInterval(() => {
        setPercentage(prev => {
          // Simulate realistic loading by slowing down as it approaches 100%
          const increment = Math.max(1, Math.floor((100 - prev) / 10));
          const newValue = Math.min(99, prev + increment);
          return newValue;
        });
      }, 400);
      
      return () => clearInterval(interval);
    } else if (percentageValue !== undefined) {
      setPercentage(percentageValue);
    }
  }, [showPercentage, percentageValue]);
  
  const sizeClass = {
    sm: "scale-75",
    md: "scale-100",
    lg: "scale-150"
  };
  
  return (
    <div className={`flex items-center justify-center ${sizeClass[size]} ${className || ''}`}>
      <Progress showAnimation showValue={showPercentage} value={percentage} />
    </div>
  );
}

export function FullPageLoading({ percentageValue }: { percentageValue?: number }) {
  return (
    <div className="fixed inset-0 bg-white dark:bg-black bg-opacity-80 dark:bg-opacity-80 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="text-center">
        <LoadingAnimation size="lg" color="red" showPercentage={true} percentageValue={percentageValue} />
        <motion.p 
          className="mt-4 text-lg font-medium text-gray-700 dark:text-gray-300"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          Loading...
        </motion.p>
      </div>
    </div>
  );
}
