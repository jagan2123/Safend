import { toast } from "@/components/ui/use-toast";
import { emitEvent, EVENT_TYPES } from './EventService';
import { sendMessChargesToAccounts } from './sales/PostOperationsService';
import { SalaryDeduction } from './PayrollService';

export interface MessCharge {
  id: string;
  employeeId: string;
  employeeName: string;
  month: string;
  year: string;
  amount: number;
  numberOfMeals: number;
  description: string;
  createdBy: string;
  createdAt: string;
  status: 'PENDING' | 'PROCESSED' | 'CANCELLED';
  processedAt?: string;
  postId?: string;
  postName?: string;
  unitPrice?: number;
  sentToAccounts?: boolean;
  accountsRequestId?: string;
  approvedByAccounts?: boolean;
  approvedByAccountsAt?: string;
  deductedFromSalary?: boolean;
  deductedFromSalaryAt?: string;
  salaryDeductionId?: string;
}

// In-memory storage for mess charges
let messCharges: MessCharge[] = [];

// In-memory storage for mess cost configurations
let messCostConfigurations: {
  postId: string;
  postName: string;
  mealCost: number;
  effectiveFrom: string;
  effectiveTo?: string;
  isActive: boolean;
}[] = [
  {
    postId: "OP-1234",
    postName: "Corporate Office Security",
    mealCost: 55,
    effectiveFrom: "2025-01-01",
    isActive: true
  },
  {
    postId: "OP-2345",
    postName: "Factory Security",
    mealCost: 50,
    effectiveFrom: "2025-01-01",
    isActive: true
  },
  {
    postId: "OP-3456",
    postName: "Hotel Security",
    mealCost: 60,
    effectiveFrom: "2025-01-01",
    isActive: true
  }
];

// Generate a unique mess charge ID
const generateMessChargeId = () => {
  return `MESS-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
};

// Get meal cost for a specific post
export const getMealCost = (postId: string): number => {
  const postConfig = messCostConfigurations.find(config => 
    config.postId === postId && config.isActive
  );
  
  if (!postConfig) {
    // Return a default cost if no configuration is found
    return 50;
  }
  
  return postConfig.mealCost;
};

// Update meal costs for a post
export const updatePostMealCost = (
  postId: string, 
  mealCost: number
) => {
  const configIndex = messCostConfigurations.findIndex(config => config.postId === postId);
  
  if (configIndex === -1) {
    return false;
  }
  
  messCostConfigurations[configIndex] = {
    ...messCostConfigurations[configIndex],
    mealCost
  };
  
  return true;
};

// Get all meal cost configurations
export const getAllMealCostConfigurations = () => {
  return messCostConfigurations;
};

// Calculate and update meal costs based on total distribution amount and meal count
export const calculateMealCostFromDistribution = (postId: string, totalAmount: number, mealCount: number) => {
  if (mealCount === 0) {
    return {
      success: false,
      message: "No meals to distribute cost to"
    };
  }
  
  // Calculate cost per meal
  const costPerMeal = Math.round(totalAmount / mealCount);
  
  // Update the costs
  const updated = updatePostMealCost(postId, costPerMeal);
  
  if (updated) {
    emitEvent(EVENT_TYPES.MESS_COST_UPDATED, {
      postId,
      newCost: costPerMeal,
      totalAmount,
      mealCount
    });
    
    return {
      success: true,
      message: "Meal cost updated successfully",
      cost: costPerMeal
    };
  } else {
    return {
      success: false,
      message: "Failed to update meal cost"
    };
  }
};

// Create a new mess charge
export const createMessCharge = (data: Omit<MessCharge, 'id' | 'createdAt' | 'status'>) => {
  // If no unit price is provided, get it from configurations
  if (!data.unitPrice && data.postId) {
    data.unitPrice = getMealCost(data.postId);
  }
  
  // Calculate amount if not provided
  if (!data.amount && data.unitPrice && data.numberOfMeals) {
    data.amount = data.unitPrice * data.numberOfMeals;
  }
  
  const newMessCharge: MessCharge = {
    id: generateMessChargeId(),
    createdAt: new Date().toISOString(),
    status: 'PENDING',
    sentToAccounts: false,
    approvedByAccounts: false,
    deductedFromSalary: false,
    ...data
  };
  
  messCharges.push(newMessCharge);
  
  emitEvent(EVENT_TYPES.MESS_CHARGE_ADDED, newMessCharge);
  
  return newMessCharge;
};

// Update an existing mess charge
export const updateMessCharge = (id: string, data: Partial<Omit<MessCharge, 'id' | 'createdAt'>>) => {
  const chargeIndex = messCharges.findIndex(charge => charge.id === id);
  
  if (chargeIndex === -1) {
    return null;
  }
  
  // Recalculate amount if unit price or number of meals changed
  let updatedData = { ...data };
  if ((data.unitPrice || data.numberOfMeals) && messCharges[chargeIndex].status === 'PENDING') {
    const unitPrice = data.unitPrice || messCharges[chargeIndex].unitPrice || 0;
    const numberOfMeals = data.numberOfMeals || messCharges[chargeIndex].numberOfMeals || 0;
    updatedData.amount = unitPrice * numberOfMeals;
  }
  
  messCharges[chargeIndex] = {
    ...messCharges[chargeIndex],
    ...updatedData
  };
  
  emitEvent(EVENT_TYPES.MESS_CHARGE_UPDATED, messCharges[chargeIndex]);
  
  return messCharges[chargeIndex];
};

// Mark a mess charge as processed
export const processMessCharge = (id: string) => {
  const chargeIndex = messCharges.findIndex(charge => charge.id === id);
  
  if (chargeIndex === -1 || messCharges[chargeIndex].status !== 'PENDING') {
    return null;
  }
  
  messCharges[chargeIndex] = {
    ...messCharges[chargeIndex],
    status: 'PROCESSED',
    processedAt: new Date().toISOString()
  };
  
  return messCharges[chargeIndex];
};

// Cancel a mess charge
export const cancelMessCharge = (id: string) => {
  const chargeIndex = messCharges.findIndex(charge => charge.id === id);
  
  if (chargeIndex === -1 || messCharges[chargeIndex].status !== 'PENDING') {
    return null;
  }
  
  messCharges[chargeIndex] = {
    ...messCharges[chargeIndex],
    status: 'CANCELLED'
  };
  
  return messCharges[chargeIndex];
};

// Get all mess charges
export const getAllMessCharges = () => {
  return messCharges;
};

// Get mess charges for a specific employee
export const getMessChargesByEmployee = (employeeId: string) => {
  return messCharges.filter(charge => charge.employeeId === employeeId);
};

// Get mess charges for a specific month and year
export const getMessChargesByMonth = (month: string, year: string) => {
  return messCharges.filter(charge => charge.month === month && charge.year === year);
};

// Get mess charges for a specific post
export const getMessChargesByPost = (postId: string) => {
  return messCharges.filter(charge => charge.postId === postId);
};

// Get a mess charge by ID
export const getMessChargeById = (id: string) => {
  return messCharges.find(charge => charge.id === id) || null;
};

// Get pending mess charges
export const getPendingMessCharges = () => {
  return messCharges.filter(charge => charge.status === 'PENDING');
};

// Calculate total mess charges for an employee for a specific month
export const calculateMessChargesForEmployee = (employeeId: string, month: string, year: string) => {
  const employeeCharges = messCharges.filter(
    charge => charge.employeeId === employeeId && 
    charge.month === month && 
    charge.year === year &&
    charge.status !== 'CANCELLED'
  );
  
  return {
    totalAmount: employeeCharges.reduce((sum, charge) => sum + charge.amount, 0),
    totalMeals: employeeCharges.reduce((sum, charge) => sum + charge.numberOfMeals, 0),
    charges: employeeCharges
  };
};

// Calculate total mess charges for a post for a specific month
export const calculateMessChargesForPost = (postId: string, month: string, year: string) => {
  const postCharges = messCharges.filter(
    charge => charge.postId === postId && 
    charge.month === month && 
    charge.year === year &&
    charge.status !== 'CANCELLED'
  );
  
  return {
    totalAmount: postCharges.reduce((sum, charge) => sum + charge.amount, 0),
    totalMeals: postCharges.reduce((sum, charge) => sum + charge.numberOfMeals, 0),
    charges: postCharges
  };
};

// Generate and send mess bill to accounts
export const sendMessBillToAccounts = async (postIds: string[], month: string, year: string) => {
  try {
    // Get charges for selected posts and month/year
    const chargesToSend = postIds.flatMap(postId => 
      messCharges.filter(
        charge => charge.postId === postId &&
        charge.month === month &&
        charge.year === year &&
        charge.status === 'PROCESSED' &&
        !charge.sentToAccounts
      )
    );
    
    if (chargesToSend.length === 0) {
      return { success: false, message: "No processed charges found to send to accounts" };
    }
    
    // Group charges by employee
    const employeeWiseCharges = chargesToSend.reduce((acc, charge) => {
      const employeeId = charge.employeeId;
      if (!acc[employeeId]) {
        acc[employeeId] = {
          employeeId,
          employeeName: charge.employeeName,
          totalAmount: 0,
          totalMeals: 0,
          charges: []
        };
      }
      
      acc[employeeId].totalAmount += charge.amount;
      acc[employeeId].totalMeals += charge.numberOfMeals;
      acc[employeeId].charges.push(charge);
      
      return acc;
    }, {} as Record<string, {
      employeeId: string;
      employeeName: string;
      totalAmount: number;
      totalMeals: number;
      charges: MessCharge[];
    }>);
    
    // Send charges to accounts
    const result = await sendMessChargesToAccounts({
      month,
      year,
      posts: postIds,
      employeeWiseCharges: Object.values(employeeWiseCharges)
    });
    
    if (result && result.success) {
      // Mark charges as sent to accounts
      chargesToSend.forEach(charge => {
        const chargeIndex = messCharges.findIndex(c => c.id === charge.id);
        if (chargeIndex !== -1) {
          messCharges[chargeIndex] = {
            ...messCharges[chargeIndex],
            sentToAccounts: true,
            accountsRequestId: result.requestId
          };
        }
      });
      
      emitEvent(EVENT_TYPES.MESS_CHARGE_ADDED, {
        type: 'batch',
        count: chargesToSend.length,
        month,
        year,
        posts: postIds
      });
      
      return { 
        success: true,
        message: `Successfully sent ${chargesToSend.length} mess charges to accounts`, 
        requestId: result.requestId
      };
    } else {
      return { success: false, message: "Failed to send mess charges to accounts" };
    }
  } catch (error) {
    console.error("Error sending mess bill to accounts:", error);
    return { success: false, message: "An error occurred while sending mess charges to accounts" };
  }
};

// Approve mess charges by accounts
export const approveMessChargesByAccounts = (requestId: string) => {
  const chargesToApprove = messCharges.filter(
    charge => charge.accountsRequestId === requestId && 
    charge.sentToAccounts && 
    !charge.approvedByAccounts
  );
  
  if (chargesToApprove.length === 0) {
    return { success: false, message: "No charges found for the provided request ID" };
  }
  
  const now = new Date().toISOString();
  
  // Update all charges with the approval status
  chargesToApprove.forEach(charge => {
    const chargeIndex = messCharges.findIndex(c => c.id === charge.id);
    if (chargeIndex !== -1) {
      messCharges[chargeIndex] = {
        ...messCharges[chargeIndex],
        approvedByAccounts: true,
        approvedByAccountsAt: now
      };
    }
  });
  
  return {
    success: true, 
    message: `Successfully approved ${chargesToApprove.length} mess charges`, 
    approvedCharges: chargesToApprove
  };
};

// Deduct mess charges from salary
export const deductMessChargesFromSalary = async (requestId: string) => {
  // Find all approved charges that haven't been deducted yet
  const chargesToDeduct = messCharges.filter(
    charge => charge.accountsRequestId === requestId && 
    charge.approvedByAccounts && 
    !charge.deductedFromSalary
  );
  
  if (chargesToDeduct.length === 0) {
    return { success: false, message: "No approved charges found for deduction" };
  }
  
  // Group charges by employee for deduction
  const employeeDeductions = chargesToDeduct.reduce((acc, charge) => {
    if (!acc[charge.employeeId]) {
      acc[charge.employeeId] = {
        employeeId: charge.employeeId,
        employeeName: charge.employeeName,
        totalAmount: 0,
        charges: []
      };
    }
    
    acc[charge.employeeId].totalAmount += charge.amount;
    acc[charge.employeeId].charges.push(charge);
    
    return acc;
  }, {} as Record<string, {
    employeeId: string;
    employeeName: string;
    totalAmount: number;
    charges: MessCharge[];
  }>);
  
  const now = new Date().toISOString();
  const deductionId = `MESS-DED-${Date.now()}`;
  
  // Create salary deductions for each employee
  Object.values(employeeDeductions).forEach(deduction => {
    // Create a deduction record - in a real system, this would integrate with PayrollService
    const salaryDeduction: SalaryDeduction = {
      type: 'MESS',
      description: `Mess charges for ${deduction.charges[0].month} ${deduction.charges[0].year}`,
      amount: deduction.totalAmount,
      reference: deductionId
    };
    
    // Mark all charges as deducted
    deduction.charges.forEach(charge => {
      const chargeIndex = messCharges.findIndex(c => c.id === charge.id);
      if (chargeIndex !== -1) {
        messCharges[chargeIndex] = {
          ...messCharges[chargeIndex],
          deductedFromSalary: true,
          deductedFromSalaryAt: now,
          salaryDeductionId: deductionId
        };
      }
    });
    
    // In a real application, we would call the PayrollService to register the deduction
    console.log(`Created salary deduction for ${deduction.employeeName}: ₹${deduction.totalAmount}`);
  });
  
  return {
    success: true,
    message: `Successfully created salary deductions for ${Object.keys(employeeDeductions).length} employees`,
    deductionId,
    totalAmount: Object.values(employeeDeductions).reduce((sum, deduction) => sum + deduction.totalAmount, 0),
    employeeCount: Object.keys(employeeDeductions).length
  };
};

// Get meal statistics for a specific post and period
export const getPostMealStatistics = (postId: string, startDate: string, endDate: string) => {
  const postCharges = messCharges.filter(
    charge => 
      charge.postId === postId && 
      new Date(charge.createdAt) >= new Date(startDate) &&
      new Date(charge.createdAt) <= new Date(endDate) &&
      charge.status !== 'CANCELLED'
  );
  
  const totalMeals = postCharges.reduce((sum, charge) => sum + charge.numberOfMeals, 0);
  const totalAmount = postCharges.reduce((sum, charge) => sum + charge.amount, 0);
  
  return {
    postId,
    totalMeals,
    totalAmount,
    avgCostPerMeal: totalMeals > 0 ? Math.round(totalAmount / totalMeals) : 0,
    mealsByEmployee: postCharges.reduce((acc, charge) => {
      if (!acc[charge.employeeId]) {
        acc[charge.employeeId] = {
          employeeId: charge.employeeId,
          employeeName: charge.employeeName,
          meals: 0,
          amount: 0
        };
      }
      
      acc[charge.employeeId].meals += charge.numberOfMeals;
      acc[charge.employeeId].amount += charge.amount;
      
      return acc;
    }, {} as Record<string, {
      employeeId: string;
      employeeName: string;
      meals: number;
      amount: number;
    }>)
  };
};

// Request payment for mess charges
export const requestPaymentForMessCharges = async (month: string, year: string, branchId?: string): Promise<{ success: boolean; requestId?: string }> => {
  // Generate a unique request ID
  const requestId = `MESS-PAY-${Date.now()}`;
  
  // Get all mess charges for the month
  const charges = await getMessCharges({
    month: month,
    year: year,
    branchId: branchId
  });
  
  // Create payment request object
  const paymentRequest = {
    requestId,
    month,
    year,
    branchId,
    totalAmount: charges.reduce((sum, charge) => sum + charge.amount, 0),
    submittedAt: new Date().toISOString(),
    status: 'pending',
    charges: charges.map(c => c.id)
  };
  
  // Save the payment request
  messPaymentRequests.push(paymentRequest);
  
  // Emit event
  emitEvent(EVENT_TYPES.MESS_CHARGE_UPDATED, {
    requestId,
    totalAmount: paymentRequest.totalAmount,
    status: 'payment_requested'
  });
  
  // Update status of all charges
  charges.forEach(charge => {
    const idx = messCharges.findIndex(c => c.id === charge.id);
    if (idx !== -1) {
      messCharges[idx] = {
        ...messCharges[idx],
        paymentRequestId: requestId,
        status: 'payment_requested'
      };
    }
  });
  
  return { success: true, requestId };
};

// Approve payment request
export const approvePaymentRequest = async (requestId: string): Promise<{ success: boolean; message: string }> => {
  const paymentRequestIndex = messPaymentRequests.findIndex(req => req.requestId === requestId);
  
  if (paymentRequestIndex === -1) {
    return { success: false, message: 'Payment request not found' };
  }
  
  const paymentRequest = messPaymentRequests[paymentRequestIndex];
  
  // Update payment request status
  messPaymentRequests[paymentRequestIndex] = {
    ...paymentRequest,
    status: 'approved',
    approvedAt: new Date().toISOString()
  };
  
  // Update all associated charges
  for (const chargeId of paymentRequest.charges) {
    const chargeIndex = messCharges.findIndex(c => c.id === chargeId);
    if (chargeIndex !== -1) {
      messCharges[chargeIndex] = {
        ...messCharges[chargeIndex],
        status: 'payment_approved'
      };
    }
  }
  
  // Emit event
  emitEvent(EVENT_TYPES.MESS_CHARGE_UPDATED, {
    requestId,
    totalAmount: paymentRequest.totalAmount,
    status: 'payment_approved'
  });
  
  return { success: true, message: `Payment request ${requestId} has been approved` };
};
