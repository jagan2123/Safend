import { emitEvent, EVENT_TYPES } from '@/services/EventService';

export interface CashAdvance {
  id: string;
  employeeId: string;
  employeeName: string;
  amount: number;
  purpose: string;
  category: 'PATROL' | 'FUEL' | 'EQUIPMENT' | 'TRAINING' | 'OTHER';
  requestDate: string;
  approvedDate?: string;
  approvedBy?: string;
  disbursedDate?: string;
  settlementDueDate?: string;
  settlementDate?: string;
  status: 'requested' | 'approved' | 'disbursed' | 'settled' | 'rejected' | 'partially_settled';
  receiptRequired: boolean;
  receiptsAttached: boolean;
  notes?: string;
  branchId?: string;
  branchName?: string;
  settledAmount?: number;
  balanceAmount?: number;
  createdAt: string;
  updatedAt?: string;
}

export interface AdvanceSettlement {
  id: string;
  advanceId: string;
  amount: number;
  settlementDate: string;
  attachments?: string[];
  notes?: string;
  settledBy: string;
  createdAt: string;
}

// Mock data for cash advances and settlements
const cashAdvances: CashAdvance[] = [];
const advanceSettlements: AdvanceSettlement[] = [];

// Function to generate a unique advance ID
const generateAdvanceId = () => {
  return `ADV-${Date.now().toString().slice(-6)}`;
};

// Function to generate a unique settlement ID
const generateSettlementId = () => {
  return `STL-${Date.now().toString().slice(-6)}`;
};

// Function to create a new cash advance request
export const createCashAdvance = (data: Omit<CashAdvance, 'id' | 'status' | 'createdAt' | 'settledAmount' | 'balanceAmount' | 'receiptsAttached'>): CashAdvance => {
  const now = new Date().toISOString();
  
  const advance: CashAdvance = {
    id: generateAdvanceId(),
    status: 'requested',
    createdAt: now,
    settledAmount: 0,
    balanceAmount: data.amount,
    receiptsAttached: false,
    ...data
  };
  
  cashAdvances.push(advance);
  
  emitEvent(EVENT_TYPES.SECURITY_CASH_ADVANCE_ISSUED, {
    advanceId: advance.id,
    employeeId: advance.employeeId,
    employeeName: advance.employeeName,
    amount: advance.amount,
    purpose: advance.purpose,
    category: advance.category
  });
  
  return advance;
};

// Function to get all cash advances
export const getCashAdvances = async (filters?: {
  employeeId?: string;
  status?: CashAdvance['status'];
  category?: CashAdvance['category'];
  branchId?: string;
  startDate?: string;
  endDate?: string;
}): Promise<CashAdvance[]> => {
  if (!filters) {
    return Promise.resolve([...cashAdvances]);
  }
  
  return Promise.resolve(cashAdvances.filter(advance => {
    if (filters.employeeId && advance.employeeId !== filters.employeeId) {
      return false;
    }
    if (filters.status && advance.status !== filters.status) {
      return false;
    }
    if (filters.category && advance.category !== filters.category) {
      return false;
    }
    if (filters.branchId && advance.branchId !== filters.branchId) {
      return false;
    }
    if (filters.startDate && new Date(advance.requestDate) < new Date(filters.startDate)) {
      return false;
    }
    if (filters.endDate && new Date(advance.requestDate) > new Date(filters.endDate)) {
      return false;
    }
    
    return true;
  }));
};

// Function to get a specific cash advance by ID
export const getCashAdvanceById = (advanceId: string): CashAdvance | undefined => {
  return cashAdvances.find(advance => advance.id === advanceId);
};

// Function to update a cash advance
export const updateCashAdvance = (advanceId: string, updates: Partial<CashAdvance>): CashAdvance | null => {
  const advanceIndex = cashAdvances.findIndex(advance => advance.id === advanceId);
  
  if (advanceIndex === -1) {
    return null;
  }
  
  cashAdvances[advanceIndex] = {
    ...cashAdvances[advanceIndex],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  return cashAdvances[advanceIndex];
};

// Function to approve a cash advance
export const approveCashAdvance = (advanceId: string, approverName: string): CashAdvance | null => {
  const advanceIndex = cashAdvances.findIndex(advance => advance.id === advanceId && advance.status === 'requested');
  
  if (advanceIndex === -1) {
    return null;
  }
  
  cashAdvances[advanceIndex] = {
    ...cashAdvances[advanceIndex],
    status: 'approved',
    approvedDate: new Date().toISOString(),
    approvedBy: approverName,
    updatedAt: new Date().toISOString()
  };
  
  return cashAdvances[advanceIndex];
};

// Function to disburse a cash advance
export const disburseCashAdvance = (advanceId: string): CashAdvance | null => {
  const advanceIndex = cashAdvances.findIndex(advance => advance.id === advanceId && advance.status === 'approved');
  
  if (advanceIndex === -1) {
    return null;
  }
  
  const now = new Date();
  const settlementDueDate = new Date();
  settlementDueDate.setDate(settlementDueDate.getDate() + 14); // Default settlement due in 14 days
  
  cashAdvances[advanceIndex] = {
    ...cashAdvances[advanceIndex],
    status: 'disbursed',
    disbursedDate: now.toISOString(),
    settlementDueDate: settlementDueDate.toISOString(),
    updatedAt: now.toISOString()
  };
  
  return cashAdvances[advanceIndex];
};

// Function to reject a cash advance
export const rejectCashAdvance = (advanceId: string, rejectionNote: string): CashAdvance | null => {
  const advanceIndex = cashAdvances.findIndex(advance => 
    advance.id === advanceId && 
    (advance.status === 'requested' || advance.status === 'approved')
  );
  
  if (advanceIndex === -1) {
    return null;
  }
  
  cashAdvances[advanceIndex] = {
    ...cashAdvances[advanceIndex],
    status: 'rejected',
    notes: rejectionNote + (cashAdvances[advanceIndex].notes ? `\n${cashAdvances[advanceIndex].notes}` : ''),
    updatedAt: new Date().toISOString()
  };
  
  return cashAdvances[advanceIndex];
};

// Function to settle an advance (fully or partially)
export const settleAdvance = (
  advanceId: string, 
  settlementData: {
    amount: number;
    settlementDate: string;
    attachments?: string[];
    notes?: string;
    settledBy: string;
  }
): { advance: CashAdvance; settlement: AdvanceSettlement } | null => {
  const advanceIndex = cashAdvances.findIndex(advance => 
    advance.id === advanceId && 
    (advance.status === 'disbursed' || advance.status === 'partially_settled')
  );
  
  if (advanceIndex === -1) {
    return null;
  }
  
  const advance = cashAdvances[advanceIndex];
  const settledAmount = (advance.settledAmount || 0) + settlementData.amount;
  const balanceAmount = advance.amount - settledAmount;
  
  // Create settlement record
  const settlement: AdvanceSettlement = {
    id: generateSettlementId(),
    advanceId,
    amount: settlementData.amount,
    settlementDate: settlementData.settlementDate,
    attachments: settlementData.attachments,
    notes: settlementData.notes,
    settledBy: settlementData.settledBy,
    createdAt: new Date().toISOString()
  };
  
  advanceSettlements.push(settlement);
  
  // Update advance record
  const newStatus = balanceAmount <= 0 ? 'settled' : 'partially_settled';
  
  cashAdvances[advanceIndex] = {
    ...advance,
    status: newStatus,
    settledAmount,
    balanceAmount: balanceAmount > 0 ? balanceAmount : 0,
    settlementDate: newStatus === 'settled' ? new Date().toISOString() : undefined,
    receiptsAttached: Boolean(settlementData.attachments?.length),
    updatedAt: new Date().toISOString()
  };
  
  emitEvent(EVENT_TYPES.SECURITY_CASH_ADVANCE_SETTLED, {
    advanceId,
    settlementId: settlement.id,
    employeeName: advance.employeeName,
    settledAmount: settlementData.amount,
    totalSettled: settledAmount,
    remainingBalance: balanceAmount,
    status: newStatus
  });
  
  return {
    advance: cashAdvances[advanceIndex],
    settlement
  };
};

// Function to get settlements for a specific advance
export const getSettlementsForAdvance = (advanceId: string): AdvanceSettlement[] => {
  return advanceSettlements.filter(settlement => settlement.advanceId === advanceId);
};

// Function to get overdue advances
export const getOverdueAdvances = (): CashAdvance[] => {
  const now = new Date();
  
  return cashAdvances.filter(advance => {
    return (advance.status === 'disbursed' || advance.status === 'partially_settled') && 
           advance.settlementDueDate && 
           new Date(advance.settlementDueDate) < now;
  });
};

// Function to generate advance summary by category
export const getAdvanceSummaryByCategory = async (
  startDate?: string, 
  endDate?: string,
  branchId?: string
): Promise<Record<string, { count: number; totalAmount: number; settledAmount: number; outstandingAmount: number }>> => {
  const filteredAdvances = cashAdvances.filter(advance => {
    if (startDate && new Date(advance.requestDate) < new Date(startDate)) {
      return false;
    }
    if (endDate && new Date(advance.requestDate) > new Date(endDate)) {
      return false;
    }
    if (branchId && advance.branchId !== branchId) {
      return false;
    }
    
    return true;
  });
  
  return Promise.resolve(filteredAdvances.reduce((summary, advance) => {
    const category = advance.category;
    if (!summary[category]) {
      summary[category] = { 
        count: 0, 
        totalAmount: 0, 
        settledAmount: 0, 
        outstandingAmount: 0 
      };
    }
    
    summary[category].count++;
    summary[category].totalAmount += advance.amount;
    summary[category].settledAmount += (advance.settledAmount || 0);
    summary[category].outstandingAmount += (advance.balanceAmount || 0);
    
    return summary;
  }, {} as Record<string, { count: number; totalAmount: number; settledAmount: number; outstandingAmount: number }>));
};
