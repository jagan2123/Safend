
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LoadingAnimation } from "@/components/ui/loading-animation";
import { PostTable } from "./posts/PostTable";
import { PostMapView } from "./posts/PostMapView";
import { postsApi } from "@/services/operations/api";
import { Post } from "@/types/operations";
import { MapPin, Plus, FileText, Search, Filter, Download } from "lucide-react";
import { PostForm } from "./posts/PostForm";
import { PostDetailView } from "./posts/PostDetailView";
import { useToast } from "@/hooks/use-toast";

// Mock posts data for testing - Fixed type of days array to use specific day literals
const MOCK_POSTS: Post[] = [
  {
    id: "1",
    branchId: "b1",
    name: "ABC Corp HQ",
    code: "ABC-001",
    type: "permanent" as const,
    clientId: "c1",
    clientName: "ABC Corporation",
    workOrderId: "wo1",
    location: {
      latitude: 19.0760,
      longitude: 72.8777,
      geofenceRadius: 100
    },
    address: "123 Business Park, Mumbai, MH 400001",
    startDate: "2024-01-01",
    dutyType: "12H" as const,
    requiredStaff: [
      {
        role: "Guard",
        count: 4,
        shift: "Day",
        startTime: "07:00",
        endTime: "19:00",
        days: ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
      },
      {
        role: "Guard",
        count: 2,
        shift: "Night",
        startTime: "19:00",
        endTime: "07:00",
        days: ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
      }
    ],
    status: "active" as const,
    createdAt: "2023-12-15T10:00:00Z",
    updatedAt: "2024-03-20T15:30:00Z"
  },
  {
    id: "2",
    branchId: "b1",
    name: "XYZ Tech Park",
    code: "XYZ-001",
    type: "permanent" as const,
    clientId: "c2",
    clientName: "XYZ Technologies",
    workOrderId: "wo2",
    location: {
      latitude: 12.9716,
      longitude: 77.5946,
      geofenceRadius: 150
    },
    address: "456 Tech Park, Bangalore, KA 560001",
    startDate: "2024-02-15",
    dutyType: "8H" as const,
    requiredStaff: [
      {
        role: "Guard",
        count: 2,
        shift: "Morning",
        startTime: "06:00",
        endTime: "14:00",
        days: ["mon", "tue", "wed", "thu", "fri"]
      },
      {
        role: "Guard",
        count: 2,
        shift: "Evening",
        startTime: "14:00",
        endTime: "22:00",
        days: ["mon", "tue", "wed", "thu", "fri"]
      },
      {
        role: "Guard",
        count: 1,
        shift: "Night",
        startTime: "22:00",
        endTime: "06:00",
        days: ["mon", "tue", "wed", "thu", "fri"]
      }
    ],
    status: "active" as const,
    createdAt: "2024-02-10T09:30:00Z",
    updatedAt: "2024-03-25T11:20:00Z"
  },
  {
    id: "3",
    branchId: "b1",
    name: "Trade Exhibition",
    code: "TEMP-001",
    type: "temporary" as const,
    clientId: "c3",
    clientName: "Event Organizers Ltd",
    location: {
      latitude: 28.6139,
      longitude: 77.2090,
      geofenceRadius: 200
    },
    address: "Exhibition Grounds, New Delhi, DL 110001",
    startDate: "2024-05-10",
    endDate: "2024-05-17",
    dutyType: "12H" as const,
    requiredStaff: [
      {
        role: "Guard",
        count: 6,
        shift: "Day",
        startTime: "08:00",
        endTime: "20:00",
        days: ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
      },
      {
        role: "Supervisor",
        count: 1,
        shift: "Day",
        startTime: "08:00",
        endTime: "20:00",
        days: ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
      },
      {
        role: "Guard",
        count: 4,
        shift: "Night",
        startTime: "20:00",
        endTime: "08:00",
        days: ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
      }
    ],
    status: "active" as const,
    createdAt: "2024-04-01T14:45:00Z",
    updatedAt: "2024-04-05T10:30:00Z"
  }
];

export function PostManagement() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeView, setActiveView] = useState("list");
  const [showPostForm, setShowPostForm] = useState(false);
  const [editPost, setEditPost] = useState<Post | null>(null);
  const [selectedPost, setSelectedPost] = useState<string | null>(null);
  const { toast } = useToast();

  // Fetch posts with mock data
  const { data: postsData, isLoading, error, refetch } = useQuery({
    queryKey: ['posts'],
    queryFn: () => {
      // Return mock data
      return Promise.resolve(MOCK_POSTS);
    }
  });

  const handleCreatePost = () => {
    setEditPost(null);
    setShowPostForm(true);
  };

  const handleEditPost = (post: Post) => {
    setEditPost(post);
    setShowPostForm(true);
  };

  const handlePostFormClose = () => {
    setShowPostForm(false);
    setEditPost(null);
  };

  const handlePostFormSubmit = async (formData: Partial<Post>) => {
    try {
      if (editPost) {
        await postsApi.updatePost(editPost.id, formData);
        toast({
          title: "Success",
          description: "Post updated successfully"
        });
      } else {
        if (formData.type === 'temporary') {
          // Cast to TempPost for temporary posts with extra fields
          const tempPostData = {
            ...formData,
            type: 'temporary' as const,
            eventName: (formData as any).eventName || 'Temporary Event',
            expiry: formData.endDate || ''
          };
          await postsApi.createTempPost(tempPostData);
          toast({
            title: "Success",
            description: "Temporary post created successfully"
          });
        } else {
          await postsApi.createFromWorkOrder(formData);
          toast({
            title: "Success",
            description: "Post created successfully"
          });
        }
      }
      refetch();
      setShowPostForm(false);
    } catch (error) {
      console.error('Error saving post:', error);
      toast({
        title: "Error",
        description: "Failed to save post",
        variant: "destructive"
      });
    }
  };

  const handleViewPost = (postId: string) => {
    setSelectedPost(postId);
  };

  const handleBackToList = () => {
    setSelectedPost(null);
  };

  // Filter posts based on search term
  const filteredPosts = postsData ? postsData.filter((post: Post) => 
    post.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.clientName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.code?.toLowerCase().includes(searchTerm.toLowerCase())
  ) : [];

  // If a post is selected, show its detail view
  if (selectedPost) {
    return (
      <PostDetailView
        postId={selectedPost}
        onBack={handleBackToList}
        onEdit={handleEditPost}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h3 className="text-xl font-bold">Post Management</h3>
          <p className="text-muted-foreground">
            Manage security posts, temporary locations, and access control rules
          </p>
        </div>
        
        <div className="flex gap-3">
          <Button onClick={handleCreatePost} className="flex gap-2 items-center">
            <Plus className="h-4 w-4" />
            <span>Add Post</span>
          </Button>
        </div>
      </div>
      
      <Card>
        <div className="p-6 border-b border-gray-200 dark:border-gray-800">
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <Tabs value={activeView} onValueChange={setActiveView} className="w-auto">
              <TabsList className="h-9">
                <TabsTrigger value="list" className="px-3 h-8">
                  <FileText className="h-4 w-4 mr-2" />
                  List View
                </TabsTrigger>
                <TabsTrigger value="map" className="px-3 h-8">
                  <MapPin className="h-4 w-4 mr-2" />
                  Map View
                </TabsTrigger>
              </TabsList>
            </Tabs>
            
            <div className="flex gap-3 w-full md:w-auto">
              <div className="relative flex-1 md:w-64">
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input 
                  placeholder="Search posts..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <Button variant="outline" size="sm" className="h-9">
                <Filter className="h-4 w-4 mr-2" />
                <span>Filter</span>
              </Button>
              
              <Button variant="outline" size="sm" className="h-9">
                <Download className="h-4 w-4 mr-2" />
                <span>Export</span>
              </Button>
            </div>
          </div>
        </div>
        
        <div className="p-0">
          {isLoading ? (
            <div className="flex items-center justify-center h-[400px]">
              <LoadingAnimation size="lg" color="red" showPercentage={true} />
            </div>
          ) : error ? (
            <div className="p-6 text-center text-red-500">
              Error loading posts. Please try again.
            </div>
          ) : (
            <>
              <TabsContent value="list" className="m-0">
                <PostTable 
                  posts={filteredPosts} 
                  onEdit={handleEditPost} 
                  onView={handleViewPost} 
                />
              </TabsContent>
              
              <TabsContent value="map" className="m-0">
                <PostMapView 
                  posts={filteredPosts} 
                  onSelectPost={handleViewPost} 
                />
              </TabsContent>
            </>
          )}
        </div>
      </Card>

      {/* Post Form Modal */}
      {showPostForm && (
        <PostForm
          isOpen={showPostForm}
          onClose={handlePostFormClose}
          onSubmit={handlePostFormSubmit}
          editData={editPost}
        />
      )}
    </div>
  );
}
