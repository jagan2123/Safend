
import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Dialog, DialogContent, DialogDescription, 
  DialogFooter, DialogHeader, DialogTitle 
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { getAllMealCostConfigurations, calculateMealCostFromDistribution, updatePostMealCost } from "@/services/MessChargeService";
import { useToastWithSound } from "@/hooks/use-toast-with-sound";
import { IndianRupee, Calculator, Check, X } from "lucide-react";

export function MealCostManager() {
  const [costConfigs, setCostConfigs] = useState(getAllMealCostConfigurations());
  const [selectedConfig, setSelectedConfig] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isAutoCalculateOpen, setIsAutoCalculateOpen] = useState(false);
  const [editedCost, setEditedCost] = useState(0);
  const [calculationInputs, setCalculationInputs] = useState({
    totalAmount: 0,
    mealCount: 0
  });
  const { toast } = useToastWithSound();
  
  const handleOpenEditDialog = (config: any) => {
    setSelectedConfig(config);
    setEditedCost(config.mealCost);
    setIsDialogOpen(true);
  };
  
  const handleSaveEditedCost = () => {
    if (!selectedConfig) return;
    
    const updated = updatePostMealCost(selectedConfig.postId, editedCost);
    
    if (updated) {
      setCostConfigs(getAllMealCostConfigurations());
      setIsDialogOpen(false);
      toast.success({
        title: "Cost Updated",
        description: `Meal cost for ${selectedConfig.postName} has been updated.`
      });
    } else {
      toast.error({
        title: "Update Failed",
        description: "Could not update meal cost. Please try again."
      });
    }
  };
  
  const handleOpenAutoCalculate = (config: any) => {
    setSelectedConfig(config);
    setCalculationInputs({
      totalAmount: 0,
      mealCount: 0
    });
    setIsAutoCalculateOpen(true);
  };
  
  const handleAutoCalculateCost = () => {
    if (!selectedConfig) return;
    
    const result = calculateMealCostFromDistribution(
      selectedConfig.postId,
      calculationInputs.totalAmount,
      calculationInputs.mealCount
    );
    
    if (result.success) {
      setCostConfigs(getAllMealCostConfigurations());
      setIsAutoCalculateOpen(false);
      toast.success({
        title: "Cost Calculated",
        description: `Meal cost for ${selectedConfig.postName} has been calculated and updated.`
      });
    } else {
      toast.error({
        title: "Calculation Failed",
        description: result.message || "Could not calculate meal cost. Please try again."
      });
    }
  };
  
  const handleInputChange = (value: string) => {
    setEditedCost(parseInt(value) || 0);
  };
  
  const handleCalculationInputChange = (field: string, value: string) => {
    setCalculationInputs({
      ...calculationInputs,
      [field]: parseInt(value) || 0
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Meal Cost Configuration</h3>
        <Button variant="outline" disabled>
          <IndianRupee className="h-4 w-4 mr-2" />
          Add New Post Configuration
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {costConfigs.map((config) => (
          <Card key={config.postId}>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">{config.postName}</CardTitle>
              <CardDescription>Effective from {new Date(config.effectiveFrom).toLocaleDateString()}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="space-y-1">
                <div className="text-sm font-medium">Cost per meal</div>
                <div className="text-2xl font-bold flex items-center">
                  <IndianRupee className="h-5 w-5 mr-1" />
                  {config.mealCost}
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex gap-2 pt-0">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => handleOpenEditDialog(config)}
              >
                Edit Cost
              </Button>
              <Button 
                className="flex-1"
                onClick={() => handleOpenAutoCalculate(config)}
              >
                <Calculator className="h-4 w-4 mr-2" />
                Auto Calculate
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      
      {/* Manual Cost Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Meal Cost</DialogTitle>
            <DialogDescription>
              {selectedConfig?.postName}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="mealCost" className="text-right">
                Cost per Meal
              </Label>
              <div className="relative col-span-3">
                <IndianRupee className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  id="mealCost"
                  type="number"
                  value={editedCost}
                  onChange={(e) => handleInputChange(e.target.value)}
                  className="pl-8"
                  min="0"
                />
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              <X className="h-4 w-4 mr-2" /> Cancel
            </Button>
            <Button onClick={handleSaveEditedCost}>
              <Check className="h-4 w-4 mr-2" /> Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Auto Calculate Dialog */}
      <Dialog open={isAutoCalculateOpen} onOpenChange={setIsAutoCalculateOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Auto Calculate Meal Cost</DialogTitle>
            <DialogDescription>
              Calculate cost per meal based on total amount and meal count
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="totalAmount" className="text-right">
                Total Amount
              </Label>
              <div className="relative col-span-3">
                <IndianRupee className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  id="totalAmount"
                  type="number"
                  value={calculationInputs.totalAmount}
                  onChange={(e) => handleCalculationInputChange("totalAmount", e.target.value)}
                  className="pl-8"
                  min="0"
                />
              </div>
            </div>
            
            <Separator />
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="mealCount" className="text-right">
                Number of Meals
              </Label>
              <Input
                id="mealCount"
                type="number"
                value={calculationInputs.mealCount}
                onChange={(e) => handleCalculationInputChange("mealCount", e.target.value)}
                className="col-span-3"
                min="1"
              />
            </div>
            
            {calculationInputs.totalAmount > 0 && calculationInputs.mealCount > 0 && (
              <div className="text-sm">
                <div className="font-medium">Calculated cost per meal:</div>
                <div className="font-bold flex items-center">
                  <IndianRupee className="h-4 w-4 mr-1" />
                  {Math.round(calculationInputs.totalAmount / calculationInputs.mealCount)}
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAutoCalculateOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAutoCalculateCost} disabled={!calculationInputs.totalAmount || !calculationInputs.mealCount}>
              <Calculator className="h-4 w-4 mr-2" />
              Calculate & Update
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
