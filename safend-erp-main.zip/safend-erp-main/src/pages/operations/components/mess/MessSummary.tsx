
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { getPostWiseMessConsumption } from "@/services/sales/PostOperationsService";
import { sendMessBillToAccounts } from "@/services/MessChargeService";
import { useToastWithSound } from "@/hooks/use-toast-with-sound";
import { Utensils, ArrowRight, IndianRupee, FileText } from "lucide-react";

export function MessSummary() {
  const [messData, setMessData] = useState<any[]>([]);
  const [selectedPosts, setSelectedPosts] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const { toast } = useToastWithSound();
  
  // Current month and year for filtering
  const currentDate = new Date();
  const currentMonth = currentDate.toLocaleString('default', { month: 'long' });
  const currentYear = currentDate.getFullYear().toString();
  
  useEffect(() => {
    const loadMessData = async () => {
      setIsLoading(true);
      try {
        // First day of current month
        const startDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).toISOString().split('T')[0];
        // Last day of current month
        const endDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).toISOString().split('T')[0];
        
        const data = await getPostWiseMessConsumption(startDate, endDate);
        setMessData(data);
      } catch (error) {
        console.error("Error loading mess data:", error);
        toast.error({
          title: "Error loading mess data",
          description: "Failed to load mess consumption data. Please try again."
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    loadMessData();
  }, []);
  
  const handleTogglePostSelection = (postId: string) => {
    if (selectedPosts.includes(postId)) {
      setSelectedPosts(selectedPosts.filter(id => id !== postId));
    } else {
      setSelectedPosts([...selectedPosts, postId]);
    }
  };
  
  const handleSendToAccounts = async () => {
    if (selectedPosts.length === 0) {
      toast.warning({
        title: "No posts selected",
        description: "Please select at least one post to send to accounts."
      });
      return;
    }
    
    setIsSending(true);
    try {
      const result = await sendMessBillToAccounts(selectedPosts, currentMonth.toLowerCase(), currentYear);
      
      if (result.success) {
        toast.success({
          title: "Mess charges sent to accounts",
          description: result.message
        });
        setSelectedPosts([]);
      } else {
        toast.error({
          title: "Error sending to accounts",
          description: result.message
        });
      }
    } catch (error) {
      console.error("Error sending to accounts:", error);
      toast.error({
        title: "Error",
        description: "An unexpected error occurred while sending mess charges to accounts."
      });
    } finally {
      setIsSending(false);
    }
  };
  
  const totalMeals = messData.reduce((total, post) => total + post.totalMeals, 0);
  const totalAmount = messData.reduce((total, post) => total + post.totalCost, 0);
  
  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              <Utensils className="h-5 w-5" />
              Mess Consumption Summary
            </CardTitle>
            <CardDescription>
              {currentMonth} {currentYear} consumption across all posts
            </CardDescription>
          </div>
          <Button 
            onClick={handleSendToAccounts} 
            disabled={isSending || selectedPosts.length === 0}
            className="flex items-center gap-2"
          >
            {isSending ? "Sending..." : "Send to Accounts"}
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {isLoading ? (
          <div className="py-6 text-center text-muted-foreground">Loading mess consumption data...</div>
        ) : messData.length === 0 ? (
          <div className="py-6 text-center text-muted-foreground">No mess consumption data available for the current month.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {messData.map((post) => (
              <Card key={post.postId} className={`
                overflow-hidden
                ${selectedPosts.includes(post.postId) ? 'ring-2 ring-primary' : ''}
                transition-all duration-200
              `}>
                <CardHeader className="p-4 pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-base font-medium">
                      {post.postName}
                    </CardTitle>
                    <div className="flex">
                      <Badge variant="outline" className="text-xs">
                        {post.totalMeals} meals
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-4 pt-2">
                  <div className="flex flex-col space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Meals consumed:</span>
                      <span>{post.totalMeals} meals</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Cost per meal:</span>
                      <span>₹{post.costPerMeal}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-medium">
                      <span>Total Cost:</span>
                      <span>₹{post.totalCost.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>Avg. Daily:</span>
                      <span>₹{post.avgDaily.toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="p-4 pt-0">
                  <Button 
                    variant={selectedPosts.includes(post.postId) ? "default" : "outline"} 
                    className="w-full"
                    onClick={() => handleTogglePostSelection(post.postId)}
                  >
                    {selectedPosts.includes(post.postId) ? (
                      <>
                        <FileText className="h-4 w-4 mr-2" />
                        Selected for Billing
                      </>
                    ) : (
                      <>
                        <IndianRupee className="h-4 w-4 mr-2" />
                        Select for Billing
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
      <CardFooter className="p-4 border-t">
        <div className="flex justify-between w-full">
          <div className="space-y-1">
            <div className="text-sm font-medium">Total Consumption</div>
            <div className="text-2xl font-bold">{totalMeals.toLocaleString()} meals</div>
          </div>
          <div className="space-y-1 text-right">
            <div className="text-sm font-medium">Total Cost</div>
            <div className="text-2xl font-bold">₹{totalAmount.toLocaleString()}</div>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
}
