
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { getMealCost } from "@/services/MessChargeService";

interface MessFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  editData: any;
}

export function MessForm({ isOpen, onClose, onSubmit, editData }: MessFormProps) {
  const [formData, setFormData] = useState({
    id: "",
    date: new Date(),
    postId: "",
    postName: "",
    employeeId: "",
    employeeName: "",
    quantity: 1,
    unitPrice: 50,
    totalAmount: 50,
    description: "",
    status: "pending"
  });
  
  const [posts, setPosts] = useState([
    { id: "OP-1234", name: "Corporate Office Security" },
    { id: "OP-2345", name: "Factory Security" },
    { id: "OP-3456", name: "Hotel Security" }
  ]);
  
  const [employees, setEmployees] = useState([
    { id: "EMP-001", name: "Rajesh Kumar" },
    { id: "EMP-002", name: "Amit Singh" },
    { id: "EMP-003", name: "Priya Sharma" },
    { id: "EMP-004", name: "Suresh Patel" }
  ]);
  
  // Initialize form data when editing
  useEffect(() => {
    if (editData) {
      setFormData({
        ...editData,
        date: editData.date ? new Date(editData.date) : new Date()
      });
    }
  }, [editData]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const updated = { ...prev, [name]: value };
      
      // Recalculate total amount if quantity or unitPrice changes
      if (name === "quantity" || name === "unitPrice") {
        const quantity = name === "quantity" ? parseFloat(value) : prev.quantity;
        const unitPrice = name === "unitPrice" ? parseFloat(value) : prev.unitPrice;
        updated.totalAmount = quantity * unitPrice;
      }
      
      return updated;
    });
  };
  
  const handleDateSelect = (date: Date | undefined) => {
    if (date) {
      setFormData(prev => ({ ...prev, date }));
    }
  };
  
  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => {
      const updated = { ...prev, [name]: value };
      
      // Update price when post changes
      if (name === "postId" && prev.postId) {
        const postId = value;
        
        // Get the updated unit price from the meal cost configuration service
        const unitPrice = getMealCost(postId);
        updated.unitPrice = unitPrice;
        updated.totalAmount = unitPrice * prev.quantity;
      }
      
      // Set post name when post is selected
      if (name === "postId") {
        const selectedPost = posts.find(post => post.id === value);
        if (selectedPost) {
          updated.postName = selectedPost.name;
        }
      }
      
      // Set employee name when employee is selected
      if (name === "employeeId") {
        const selectedEmployee = employees.find(emp => emp.id === value);
        if (selectedEmployee) {
          updated.employeeName = selectedEmployee.name;
        }
      }
      
      return updated;
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>
              {editData ? "Edit Meal Record" : "Add New Meal Record"}
            </DialogTitle>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="date" className="text-right">
                Date
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    id="date"
                    variant="outline"
                    className={cn(
                      "w-[240px] justify-start text-left font-normal col-span-3",
                      !formData.date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.date ? format(formData.date, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.date}
                    onSelect={handleDateSelect}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="postId" className="text-right">
                Post
              </Label>
              <Select 
                value={formData.postId} 
                onValueChange={(value) => handleSelectChange("postId", value)}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select a security post" />
                </SelectTrigger>
                <SelectContent>
                  {posts.map(post => (
                    <SelectItem key={post.id} value={post.id}>
                      {post.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="employeeId" className="text-right">
                Employee
              </Label>
              <Select 
                value={formData.employeeId} 
                onValueChange={(value) => handleSelectChange("employeeId", value)}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select employee" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map(employee => (
                    <SelectItem key={employee.id} value={employee.id}>
                      {employee.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="quantity" className="text-right">
                Number of Meals
              </Label>
              <Input
                id="quantity"
                name="quantity"
                type="number"
                value={formData.quantity}
                onChange={handleChange}
                className="col-span-3"
                min="1"
              />
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="unitPrice" className="text-right">
                Unit Price
              </Label>
              <Input
                id="unitPrice"
                name="unitPrice"
                type="number"
                value={formData.unitPrice}
                onChange={handleChange}
                className="col-span-3"
                min="0"
              />
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="totalAmount" className="text-right">
                Total Amount
              </Label>
              <Input
                id="totalAmount"
                name="totalAmount"
                type="number"
                value={formData.totalAmount}
                readOnly
                className="col-span-3 bg-muted"
              />
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="description" className="text-right">
                Description
              </Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                className="col-span-3"
                rows={2}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              {editData ? "Update Record" : "Add Record"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
