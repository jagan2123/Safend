
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CalendarDays, UserX, ChevronRight } from "lucide-react";
import { format, addDays } from 'date-fns';
import { RotaGap } from "@/types/operations";

interface RotaGapsWidgetProps {
  data: RotaGap[];
  config?: Record<string, any>;
}

export default function RotaGapsWidget({ data, config }: RotaGapsWidgetProps) {
  const defaultConfig = {
    daysToShow: 3,
    showFilled: false,
    showVacant: true,
  };

  // Combine default config with user customizations
  const widgetConfig = config ? { ...defaultConfig, ...config } : defaultConfig;

  // Generate array of next n days
  const getDates = () => {
    const dates = [];
    const today = new Date();
    
    for (let i = 0; i < widgetConfig.daysToShow; i++) {
      const date = addDays(today, i);
      dates.push(format(date, 'yyyy-MM-dd'));
    }
    
    return dates;
  };

  // Filter data based on config
  const filteredData = data.filter(item => {
    // Only show items for the selected dates
    if (!getDates().includes(item.date)) {
      return false;
    }
    
    // Filter by vacancy status
    if (!widgetConfig.showVacant && item.gap === 0) {
      return false;
    }
    
    if (!widgetConfig.showFilled && item.gap === item.required) {
      return false;
    }
    
    return true;
  });

  // Group data by date
  const groupedData = filteredData.reduce((acc, item) => {
    if (!acc[item.date]) {
      acc[item.date] = [];
    }
    acc[item.date].push(item);
    return acc;
  }, {} as Record<string, RotaGap[]>);

  // Format date for display
  const formatDateDisplay = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = addDays(today, 1);
    
    if (format(date, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd')) {
      return 'Today';
    } else if (format(date, 'yyyy-MM-dd') === format(tomorrow, 'yyyy-MM-dd')) {
      return 'Tomorrow';
    } else {
      return format(date, 'EEE, MMM d');
    }
  };

  // Get status color based on gap percentage
  const getStatusColor = (gap: number, required: number) => {
    const gapPercentage = (gap / required) * 100;
    
    if (gapPercentage === 0) return "bg-green-500";
    if (gapPercentage <= 25) return "bg-amber-500";
    if (gapPercentage <= 50) return "bg-orange-500";
    return "bg-red-500";
  };

  if (data.length === 0) {
    return (
      <div className="h-[200px] flex flex-col items-center justify-center text-muted-foreground">
        <CalendarDays className="h-12 w-12 mb-2 opacity-50" />
        <p>No rota gaps found for the selected period</p>
      </div>
    );
  }

  return (
    <div className="h-[260px]">
      <ScrollArea className="h-full">
        {getDates().map((date) => (
          <div key={date} className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <div className="font-medium">{formatDateDisplay(date)}</div>
              {groupedData[date]?.length > 0 ? (
                <Badge variant={
                  groupedData[date].some(item => item.gap > 0) ? "destructive" : "outline"
                }>
                  {groupedData[date]?.length} Posts
                </Badge>
              ) : null}
            </div>
            
            {groupedData[date] && groupedData[date].length > 0 ? (
              <div className="space-y-2">
                {groupedData[date].map((gap) => (
                  <div 
                    key={`${gap.post.id}-${gap.shift}-${gap.role}`} 
                    className="bg-background border rounded-lg p-2 text-sm flex justify-between items-center"
                  >
                    <div>
                      <div className="font-medium">{gap.post.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {gap.shift} - {gap.role}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center">
                        <div className={`w-2 h-2 rounded-full mr-1 ${getStatusColor(gap.gap, gap.required)}`}></div>
                        <span>
                          {gap.filled}/{gap.required} Filled
                        </span>
                      </div>
                      <Button variant="ghost" size="icon" className="h-6 w-6">
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-background border rounded-lg p-4 text-center text-muted-foreground">
                <UserX className="h-5 w-5 mx-auto mb-1" />
                <p className="text-sm">All positions filled</p>
              </div>
            )}
          </div>
        ))}
        
        <div className="mt-4 flex justify-end">
          <Button variant="outline" size="sm">
            View all gaps
          </Button>
        </div>
      </ScrollArea>
    </div>
  );
}
