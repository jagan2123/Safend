
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Wallet } from "lucide-react";
import { format } from 'date-fns';

interface SalaryAdvance {
  id: string;
  employeeName: string;
  amount: number;
  reason: string;
  status: 'pending' | 'approved' | 'processed';
  txnDate: string;
}

interface SalaryAdvancesWidgetProps {
  data: SalaryAdvance[];
  config?: Record<string, any>;
}

export default function SalaryAdvancesWidget({ data, config }: SalaryAdvancesWidgetProps) {
  const defaultConfig = {
    showPending: true,
    showApproved: true,
    showProcessed: false,
    limit: 5,
  };

  // Combine default config with user customizations
  const widgetConfig = config ? { ...defaultConfig, ...config } : defaultConfig;

  // Filter data based on config
  const filteredData = data
    .filter(item => {
      if (item.status === 'pending' && !widgetConfig.showPending) return false;
      if (item.status === 'approved' && !widgetConfig.showApproved) return false;
      if (item.status === 'processed' && !widgetConfig.showProcessed) return false;
      return true;
    })
    .sort((a, b) => new Date(b.txnDate).getTime() - new Date(a.txnDate).getTime())
    .slice(0, widgetConfig.limit);

  // Format date
  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'MMM d');
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', { 
      style: 'currency', 
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Get badge for status
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-amber-500">Pending</Badge>;
      case 'approved':
        return <Badge className="bg-green-500">Approved</Badge>;
      case 'processed':
        return <Badge className="bg-blue-500">Processed</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  if (data.length === 0) {
    return (
      <div className="h-[200px] flex flex-col items-center justify-center text-muted-foreground">
        <Wallet className="h-12 w-12 mb-2 opacity-50" />
        <p>No salary advances found</p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[260px]">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[140px]">Employee</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Date</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredData.length > 0 ? (
            filteredData.map((advance) => (
              <TableRow key={advance.id}>
                <TableCell className="font-medium">
                  <div>{advance.employeeName}</div>
                  <div className="text-xs text-muted-foreground truncate max-w-[140px]" title={advance.reason}>
                    {advance.reason}
                  </div>
                </TableCell>
                <TableCell>{formatCurrency(advance.amount)}</TableCell>
                <TableCell>{getStatusBadge(advance.status)}</TableCell>
                <TableCell className="text-right">{formatDate(advance.txnDate)}</TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={4} className="text-center py-10 text-muted-foreground">
                No advances found matching your filters
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </ScrollArea>
  );
}
