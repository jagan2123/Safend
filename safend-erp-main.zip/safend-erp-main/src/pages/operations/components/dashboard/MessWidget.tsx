
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Utensils, ArrowRight } from "lucide-react";
import { format } from 'date-fns';
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

interface MessMeal {
  id: string;
  employeeName: string;
  postName: string;
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snacks';
  quantity: number;
  txnDate: string;
}

interface MessWidgetProps {
  data: MessMeal[];
  config?: Record<string, any>;
}

export default function MessWidget({ data, config }: MessWidgetProps) {
  const navigate = useNavigate();
  const defaultConfig = {
    showBreakfast: true,
    showLunch: true,
    showDinner: true,
    showSnacks: false,
    limit: 5,
  };

  // Combine default config with user customizations
  const widgetConfig = config ? { ...defaultConfig, ...config } : defaultConfig;

  // Filter data based on config
  const filteredData = data
    .filter(item => {
      if (item.mealType === 'breakfast' && !widgetConfig.showBreakfast) return false;
      if (item.mealType === 'lunch' && !widgetConfig.showLunch) return false;
      if (item.mealType === 'dinner' && !widgetConfig.showDinner) return false;
      if (item.mealType === 'snacks' && !widgetConfig.showSnacks) return false;
      return true;
    })
    .sort((a, b) => new Date(b.txnDate).getTime() - new Date(a.txnDate).getTime())
    .slice(0, widgetConfig.limit);

  // Format date
  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'MMM d, HH:mm');
  };

  // Get badge for meal type
  const getMealBadge = (mealType: string) => {
    switch (mealType) {
      case 'breakfast':
        return <Badge className="bg-amber-500">Breakfast</Badge>;
      case 'lunch':
        return <Badge className="bg-green-500">Lunch</Badge>;
      case 'dinner':
        return <Badge className="bg-blue-500">Dinner</Badge>;
      case 'snacks':
        return <Badge className="bg-purple-500">Snacks</Badge>;
      default:
        return <Badge>{mealType}</Badge>;
    }
  };
  
  // Navigate to Mess Management section
  const goToMessManagement = () => {
    navigate('/operations', { state: { tab: 'mess' } });
  };

  if (data.length === 0) {
    return (
      <div className="h-[200px] flex flex-col items-center justify-center text-muted-foreground">
        <Utensils className="h-12 w-12 mb-2 opacity-50" />
        <p>No mess meals found</p>
        <Button 
          variant="link"
          className="mt-2"
          onClick={goToMessManagement}
        >
          Go to Mess Management
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <ScrollArea className="flex-1">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[140px]">Employee</TableHead>
              <TableHead>Meal</TableHead>
              <TableHead>Qty</TableHead>
              <TableHead className="text-right">Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredData.length > 0 ? (
              filteredData.map((meal) => (
                <TableRow key={meal.id}>
                  <TableCell className="font-medium">
                    <div>{meal.employeeName}</div>
                    <div className="text-xs text-muted-foreground">
                      {meal.postName}
                    </div>
                  </TableCell>
                  <TableCell>{getMealBadge(meal.mealType)}</TableCell>
                  <TableCell>{meal.quantity}</TableCell>
                  <TableCell className="text-right">{formatDate(meal.txnDate)}</TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-10 text-muted-foreground">
                  No meals found matching your filters
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </ScrollArea>
      
      <div className="mt-4 pt-2 border-t border-gray-200 dark:border-gray-700">
        <Button 
          variant="outline" 
          size="sm" 
          className="w-full flex justify-between"
          onClick={goToMessManagement}
        >
          <span>View All Mess Records</span>
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
