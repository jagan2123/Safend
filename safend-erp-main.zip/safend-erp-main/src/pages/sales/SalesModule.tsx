import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import {
  Users,
  FileText,
  ClipboardList,
  MessageSquare,
  BarChart2,
  Calendar,
  Filter,
  UserPlus,
  FilePlus,
  Mail,
  ChevronDown,
  FileSignature,
  DollarSign
} from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { LeadsTable } from "./components/LeadsTable";
import { QuotationsTable } from "./components/QuotationsTable";
import { WorkordersTable } from "./components/WorkordersTable";
import { FollowupsTable } from "./components/FollowupsTable";
import { SalesReportView } from "./components/SalesReportView";
import { SalesCalendarView } from "./components/SalesCalendarView";
import { LeadForm } from "./components/LeadForm";
import { QuotationForm } from "./components/QuotationForm";
import { ContactForm } from "./components/ContactForm";
import { WorkorderForm } from "./components/WorkorderForm";
import { FollowupForm } from "./components/FollowupForm";
import { AgreementsTable } from "./components/AgreementsTable";
import { AgreementForm } from "./components/AgreementForm";
import { AgingInvoicesTable } from "./components/AgingInvoicesTable";
import { AgingInvoiceForm } from "./components/AgingInvoiceForm";
import { ClientProfile } from "./components/ClientProfile";
import { ModuleHeader } from "@/components/ui/module-header";
import { ModuleCard } from "@/components/ui/module-card";
import { LoadingAnimation } from "@/components/ui/loading-animation";

const salesTabs = [
  { id: "crm", label: "Client Management", icon: Users },
  { id: "followups", label: "Follow-ups", icon: MessageSquare },
  { id: "quotations", label: "Quotations", icon: FileText },
  { id: "agreements", label: "Agreements", icon: FileSignature },
  { id: "workorders", label: "Work Orders", icon: ClipboardList },
  { id: "aging", label: "Collections", icon: DollarSign },
  { id: "reports", label: "Reports", icon: BarChart2 },
  { id: "calendar", label: "Calendar", icon: Calendar }
];

// Filter options for each tab
const filterOptions = {
  "crm": ["All Clients", "New Leads", "Qualified Leads", "Opportunities", "Existing Clients", "Inactive Clients"],
  "quotations": ["All Quotations", "Draft", "Sent", "Revised", "Accepted", "Rejected"],
  "workorders": ["All Workorders", "Pending", "Active", "Completed", "On Hold"],
  "followups": ["All Follow-ups", "Today", "This Week", "This Month", "Overdue"],
  "reports": ["Sales Performance", "Revenue Analysis", "Pipeline Status", "Conversion Rate", "Activity Reports"],
  "calendar": ["All Events", "Meetings", "Calls", "Deadlines", "Reminders"],
  "agreements": ["All Agreements", "Draft", "Signed", "Active", "Expired", "Terminated"],
  "aging": ["All Invoices", "0-30 Days", "31-60 Days", "61-90 Days", "90+ Days"]
};

export function SalesModule() {
  const [activeTab, setActiveTab] = useState("crm");
  const [activeFilter, setActiveFilter] = useState("All Clients");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterIsOpen, setFilterIsOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  
  // Form handling states
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [showQuotationForm, setShowQuotationForm] = useState(false);
  const [showContactForm, setShowContactForm] = useState(false);
  const [showWorkorderForm, setShowWorkorderForm] = useState(false);
  const [showFollowupForm, setShowFollowupForm] = useState(false);
  const [showAgreementForm, setShowAgreementForm] = useState(false);
  const [showAgingInvoiceForm, setShowAgingInvoiceForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);

  const handleTabChange = (value: string) => {
    setIsLoading(true);
    setActiveTab(value);
    setActiveFilter(filterOptions[value as keyof typeof filterOptions][0]);
    
    // Simulate loading delay
    setTimeout(() => {
      setIsLoading(false);
      
      toast({
        title: `Viewing ${value.charAt(0).toUpperCase() + value.slice(1)}`,
        description: `Switched to ${value} tab`,
        duration: 2000,
      });
    }, 600);
  };
  
  const handleFilterChange = (filter: string) => {
    setActiveFilter(filter);
    setFilterIsOpen(false);
    
    toast({
      title: `Filter Applied: ${filter}`,
      description: `Showing data for ${filter.toLowerCase()}`,
      duration: 1500,
    });
  };
  
  const handleClientSelect = (client: any) => {
    setSelectedClient(client);
  };

  const getActionButton = () => {
    switch (activeTab) {
      case "crm":
        return (
          <Button className="bg-safend-red hover:bg-red-700" onClick={() => {
            setEditingItem(null);
            setShowLeadForm(true);
          }}>
            <UserPlus className="mr-2 h-4 w-4" />
            Add Client
          </Button>
        );
      case "quotations":
        return (
          <Button className="bg-safend-red hover:bg-red-700" onClick={() => {
            setEditingItem(null);
            setShowQuotationForm(true);
          }}>
            <FilePlus className="mr-2 h-4 w-4" />
            Create Quotation
          </Button>
        );
      case "workorders":
        return (
          <Button className="bg-safend-red hover:bg-red-700" onClick={() => {
            setEditingItem(null);
            setShowWorkorderForm(true);
          }}>
            <ClipboardList className="mr-2 h-4 w-4" />
            New Work Order
          </Button>
        );
      case "followups":
        return (
          <Button className="bg-safend-red hover:bg-red-700" onClick={() => {
            setEditingItem(null);
            setShowFollowupForm(true);
          }}>
            <Mail className="mr-2 h-4 w-4" />
            Schedule Follow-up
          </Button>
        );
      case "agreements":
        return (
          <Button className="bg-safend-red hover:bg-red-700" onClick={() => {
            setEditingItem(null);
            setShowAgreementForm(true);
          }}>
            <FileSignature className="mr-2 h-4 w-4" />
            New Agreement
          </Button>
        );
      case "aging":
        return (
          <Button className="bg-safend-red hover:bg-red-700" onClick={() => {
            setEditingItem(null);
            setShowAgingInvoiceForm(true);
          }}>
            <DollarSign className="mr-2 h-4 w-4" />
            Add Collection Task
          </Button>
        );
      default:
        return null;
    }
  };

  const currentFilters = filterOptions[activeTab as keyof typeof filterOptions];

  // Handling edit actions
  const handleEdit = (item: any, type: string) => {
    setEditingItem(item);
    switch (type) {
      case "lead":
        setShowLeadForm(true);
        break;
      case "quotation":
        setShowQuotationForm(true);
        break;
      case "contact":
        setShowContactForm(true);
        break;
      case "workorder":
        setShowWorkorderForm(true);
        break;
      case "followup":
        setShowFollowupForm(true);
        break;
      case "agreement":
        setShowAgreementForm(true);
        break;
      case "aging":
        setShowAgingInvoiceForm(true);
        break;
      default:
        break;
    }
  };

  // Form submission handlers
  const handleFormSubmit = (formData: any, type: string) => {
    // This would connect to your backend in a real application
    const successMessage = editingItem 
      ? `${type} updated successfully` 
      : `New ${type} created successfully`;
      
    toast({
      title: "Success",
      description: successMessage,
      duration: 3000,
    });

    // Close all forms
    setShowLeadForm(false);
    setShowQuotationForm(false);
    setShowContactForm(false);
    setShowWorkorderForm(false);
    setShowFollowupForm(false);
    setShowAgreementForm(false);
    setShowAgingInvoiceForm(false);
    setEditingItem(null);
  };

  return (
    <Layout>
      <motion.div
        className="space-y-6 page-transition"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <ModuleHeader
          title="Sales Management"
          description={activeTab === "aging" ? 
            "Manage outstanding invoices and collections" : 
            "Manage leads, quotations, agreements, work orders and follow-ups"}
          actionLabel={getActionButton() ? undefined : undefined}
          actionIcon={getActionButton() ? undefined : undefined}
          onAction={undefined}
        />

        <ModuleCard className="overflow-hidden">
          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <div className="p-6 border-b border-gray-200 dark:border-gray-800">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <TabsList className="grid grid-cols-2 md:grid-cols-8 gap-1 w-full md:w-auto bg-gray-100 dark:bg-gray-800 p-1 rounded-lg">
                  {salesTabs.map(tab => (
                    <TabsTrigger 
                      key={tab.id} 
                      value={tab.id}
                      className="flex gap-2 items-center transition-all duration-200"
                    >
                      <tab.icon className="h-4 w-4" />
                      <span className="hidden sm:inline">{tab.label}</span>
                    </TabsTrigger>
                  ))}
                </TabsList>
                
                <div className="flex items-center gap-3">
                  {getActionButton()}
                  <DropdownMenu open={filterIsOpen} onOpenChange={setFilterIsOpen}>
                    <DropdownMenuTrigger asChild>
                      <motion.button 
                        className="flex items-center gap-2 px-4 py-2 rounded-lg border bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 transition-all duration-300 shadow-sm"
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                      >
                        <Filter className="h-4 w-4" />
                        <span>{activeFilter}</span>
                        <ChevronDown className={`h-4 w-4 transition-transform duration-300 ${filterIsOpen ? 'rotate-180' : ''}`} />
                      </motion.button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="animate-in fade-in-80 w-56">
                      {currentFilters.map((filter) => (
                        <DropdownMenuItem 
                          key={filter} 
                          onClick={() => handleFilterChange(filter)}
                          className={`cursor-pointer transition-colors ${filter === activeFilter ? 'bg-red-100 dark:bg-red-900/20 font-medium' : ''}`}
                        >
                          {filter}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </div>
            
            {isLoading ? (
              <div className="flex items-center justify-center h-[400px]">
                <div className="text-center">
                  <LoadingAnimation size="lg" color="red" />
                  <p className="mt-4 text-gray-500">Loading {activeTab} data...</p>
                </div>
              </div>
            ) : (
              <div className="p-6">
                {/* CRM Tab Content */}
                <TabsContent value="crm" className="space-y-6 animate-in fade-in-50">
                  {selectedClient ? (
                    <ClientProfile 
                      client={selectedClient} 
                      onBack={() => setSelectedClient(null)}
                      onEdit={handleEdit}
                    />
                  ) : (
                    <>
                      <div className="bg-gradient-to-r from-red-50 to-gray-50 dark:from-red-900/20 dark:to-gray-900/20 p-6 rounded-lg border border-red-100 dark:border-red-800/30">
                        <h3 className="text-lg font-medium mb-2">Client Management Dashboard</h3>
                        <p className="text-muted-foreground">
                          Manage all your leads and clients, track opportunities, and monitor the sales pipeline.
                        </p>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                        <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-red">
                          <h4 className="font-semibold text-gray-600 dark:text-gray-300">New Leads</h4>
                          <p className="text-3xl font-bold stat-text-red mt-2">24</p>
                          <p className="text-xs text-muted-foreground mt-1">Last 7 days</p>
                        </Card>
                        <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-black">
                          <h4 className="font-semibold text-gray-600 dark:text-gray-300">Opportunities</h4>
                          <p className="text-3xl font-bold stat-text-black mt-2">18</p>
                          <p className="text-xs text-muted-foreground mt-1">Current pipeline</p>
                        </Card>
                        <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-gray">
                          <h4 className="font-semibold text-gray-600 dark:text-gray-300">Active Clients</h4>
                          <p className="text-3xl font-bold stat-text-gray mt-2">36</p>
                          <p className="text-xs text-muted-foreground mt-1">With ongoing contracts</p>
                        </Card>
                        <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-red">
                          <h4 className="font-semibold text-gray-600 dark:text-gray-300">Conversion Rate</h4>
                          <p className="text-3xl font-bold stat-text-red mt-2">42%</p>
                          <p className="text-xs text-muted-foreground mt-1">Lead to client</p>
                        </Card>
                      </div>
                      
                      <LeadsTable 
                        filter={activeFilter}
                        searchTerm={searchTerm}
                        onEdit={(item) => handleEdit(item, "lead")}
                        onClientSelect={handleClientSelect}
                      />
                    </>
                  )}
                </TabsContent>
                
                {/* Quotations Tab Content */}
                <TabsContent value="quotations" className="space-y-6 animate-in fade-in-50">
                  <div className="bg-gradient-to-r from-red-50 to-gray-50 dark:from-red-900/20 dark:to-gray-900/20 p-6 rounded-lg border border-red-100 dark:border-red-800/30">
                    <h3 className="text-lg font-medium mb-2">Quotation Management</h3>
                    <p className="text-muted-foreground">
                      Create, track, and manage quotations for your clients and prospects.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-black">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Total</h4>
                      <p className="text-3xl font-bold stat-text-black mt-2">45</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-gray">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Pending</h4>
                      <p className="text-3xl font-bold stat-text-gray mt-2">21</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-red">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Accepted</h4>
                      <p className="text-3xl font-bold stat-text-red mt-2">16</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-gray">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Rejected</h4>
                      <p className="text-3xl font-bold stat-text-gray mt-2">8</p>
                    </Card>
                  </div>
                  
                  <QuotationsTable 
                    filter={activeFilter}
                    searchTerm={searchTerm}
                    onEdit={(item) => handleEdit(item, "quotation")}
                  />
                </TabsContent>
                
                {/* Agreements Tab Content */}
                <TabsContent value="agreements" className="space-y-6 animate-in fade-in-50">
                  <div className="bg-gradient-to-r from-red-50 to-gray-50 dark:from-red-900/20 dark:to-gray-900/20 p-6 rounded-lg border border-red-100 dark:border-red-800/30">
                    <h3 className="text-lg font-medium mb-2">Agreements Management</h3>
                    <p className="text-muted-foreground">
                      Create, manage, and track all client agreements and contracts.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-gray">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Draft</h4>
                      <p className="text-3xl font-bold stat-text-gray mt-2">12</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-red">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Signed</h4>
                      <p className="text-3xl font-bold stat-text-red mt-2">28</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-black">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Active</h4>
                      <p className="text-3xl font-bold stat-text-black mt-2">24</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-gray">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Expired</h4>
                      <p className="text-3xl font-bold stat-text-gray mt-2">7</p>
                    </Card>
                  </div>
                  
                  <AgreementsTable
                    filter={activeFilter}
                    searchTerm={searchTerm}
                    onEdit={(item) => handleEdit(item, "agreement")}
                  />
                </TabsContent>
                
                {/* Rest of the tab contents - keep same structure but update colors */}
                <TabsContent value="aging" className="space-y-6 animate-in fade-in-50">
                  <div className="bg-gradient-to-r from-red-50 to-gray-50 dark:from-red-900/20 dark:to-gray-900/20 p-6 rounded-lg border border-red-100 dark:border-red-800/30">
                    <h3 className="text-lg font-medium mb-2">Aging Invoice Collection</h3>
                    <p className="text-muted-foreground">
                      Track and manage overdue invoices and collection activities.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-gray">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">0-30 Days</h4>
                      <p className="text-3xl font-bold stat-text-gray mt-2">₹5.2L</p>
                      <p className="text-xs text-muted-foreground mt-1">14 invoices</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-black">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">31-60 Days</h4>
                      <p className="text-3xl font-bold stat-text-black mt-2">₹3.7L</p>
                      <p className="text-xs text-muted-foreground mt-1">8 invoices</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-gray">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">61-90 Days</h4>
                      <p className="text-3xl font-bold stat-text-gray mt-2">₹2.1L</p>
                      <p className="text-xs text-muted-foreground mt-1">5 invoices</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-red">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">90+ Days</h4>
                      <p className="text-3xl font-bold stat-text-red mt-2">₹1.8L</p>
                      <p className="text-xs text-muted-foreground mt-1">3 invoices</p>
                    </Card>
                  </div>
                  
                  <AgingInvoicesTable 
                    filter={activeFilter}
                    searchTerm={searchTerm}
                    onEdit={(item) => handleEdit(item, "aging")}
                  />
                </TabsContent>
                
                {/* Workorders Tab Content */}
                <TabsContent value="workorders" className="space-y-6 animate-in fade-in-50">
                  <div className="bg-gradient-to-r from-red-50 to-gray-50 dark:from-red-900/20 dark:to-gray-900/20 p-6 rounded-lg border border-red-100 dark:border-red-800/30">
                    <h3 className="text-lg font-medium mb-2">Work Orders Management</h3>
                    <p className="text-muted-foreground">
                      Manage work orders, service agreements, and ongoing contracts.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-gray">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Total</h4>
                      <p className="text-3xl font-bold stat-text-gray mt-2">82</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-red">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Active</h4>
                      <p className="text-3xl font-bold stat-text-red mt-2">36</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-black">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Completed</h4>
                      <p className="text-3xl font-bold stat-text-black mt-2">41</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-gray">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Pending</h4>
                      <p className="text-3xl font-bold stat-text-gray mt-2">5</p>
                    </Card>
                  </div>
                  
                  <WorkordersTable 
                    filter={activeFilter}
                    searchTerm={searchTerm}
                    onEdit={(item) => handleEdit(item, "workorder")}
                  />
                </TabsContent>
                
                {/* Follow-ups Tab Content */}
                <TabsContent value="followups" className="space-y-6 animate-in fade-in-50">
                  <div className="bg-gradient-to-r from-red-50 to-gray-50 dark:from-red-900/20 dark:to-gray-900/20 p-6 rounded-lg border border-red-100 dark:border-red-800/30">
                    <h3 className="text-lg font-medium mb-2">Follow-up Management</h3>
                    <p className="text-muted-foreground">
                      Schedule, manage and track all follow-ups with clients and prospects.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-red">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Today</h4>
                      <p className="text-3xl font-bold stat-text-red mt-2">8</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-black">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">This Week</h4>
                      <p className="text-3xl font-bold stat-text-black mt-2">24</p>
                    </Card>
                    <Card className="p-6 hover:shadow-lg transition-shadow border-t-4 stat-border-gray">
                      <h4 className="font-semibold text-gray-600 dark:text-gray-300">Overdue</h4>
                      <p className="text-3xl font-bold stat-text-gray mt-2">3</p>
                    </Card>
                  </div>
                  
                  <FollowupsTable 
                    filter={activeFilter}
                    searchTerm={searchTerm}
                    onEdit={(item) => handleEdit(item, "followup")}
                  />
                </TabsContent>
                
                {/* Reports Tab Content */}
                <TabsContent value="reports" className="space-y-6 animate-in fade-in-50">
                  <div className="bg-gradient-to-r from-red-50 to-gray-50 dark:from-red-900/20 dark:to-gray-900/20 p-6 rounded-lg border border-red-100 dark:border-red-800/30">
                    <h3 className="text-lg font-medium mb-2">Sales Reports</h3>
                    <p className="text-muted-foreground">
                      Access and analyze sales performance metrics and trends.
                    </p>
                  </div>
                  
                  <SalesReportView filter={activeFilter} />
                </TabsContent>
                
                {/* Calendar Tab Content */}
                <TabsContent value="calendar" className="space-y-6 animate-in fade-in-50">
                  <div className="bg-gradient-to-r from-red-50 to-gray-50 dark:from-red-900/20 dark:to-gray-900/20 p-6 rounded-lg border border-red-100 dark:border-red-800/30">
                    <h3 className="text-lg font-medium mb-2">Sales Calendar</h3>
                    <p className="text-muted-foreground">
                      Schedule and manage meetings, calls, and important sales deadlines.
                    </p>
                  </div>
                  
                  <SalesCalendarView filter={activeFilter} />
                </TabsContent>
              </div>
            )}
          </Tabs>
        </ModuleCard>
      </motion.div>

      {/* Forms */}
      {showLeadForm && 
        <LeadForm 
          isOpen={showLeadForm} 
          onClose={() => setShowLeadForm(false)} 
          onSubmit={(data) => handleFormSubmit(data, "lead")}
          editData={editingItem}
        />
      }
      
      {showQuotationForm && 
        <QuotationForm 
          isOpen={showQuotationForm} 
          onClose={() => setShowQuotationForm(false)} 
          onSubmit={(data) => handleFormSubmit(data, "quotation")}
          editData={editingItem}
        />
      }
      
      {showContactForm && 
        <ContactForm 
          isOpen={showContactForm} 
          onClose={() => setShowContactForm(false)} 
          onSubmit={(data) => handleFormSubmit(data, "contact")}
          editData={editingItem}
        />
      }
      
      {showWorkorderForm && 
        <WorkorderForm 
          isOpen={showWorkorderForm} 
          onClose={() => setShowWorkorderForm(false)} 
          onSubmit={(data) => handleFormSubmit(data, "workorder")}
          editData={editingItem}
        />
      }
      
      {showFollowupForm && 
        <FollowupForm 
          isOpen={showFollowupForm} 
          onClose={() => setShowFollowupForm(false)} 
          onSubmit={(data) => handleFormSubmit(data, "followup")}
          editData={editingItem}
        />
      }
      
      {showAgreementForm && 
        <AgreementForm 
          isOpen={showAgreementForm} 
          onClose={() => setShowAgreementForm(false)}
          onSubmit={(data) => handleFormSubmit(data, "agreement")}
          editData={editingItem}
        />
      }
      
      {showAgingInvoiceForm && 
        <AgingInvoiceForm 
          isOpen={showAgingInvoiceForm} 
          onClose={() => setShowAgingInvoiceForm(false)}
          onSubmit={(data) => handleFormSubmit(data, "aging invoice")}
          editData={editingItem}
        />
      }
    </Layout>
  );
}
