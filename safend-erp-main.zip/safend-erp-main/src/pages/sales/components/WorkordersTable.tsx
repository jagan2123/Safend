
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, Edit, Trash2, Download, CheckCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Mock data for workorders
const mockWorkorders = [
  {
    id: "WO-2025-0078",
    client: "Summit Security Limited",
    location: "Canary Wharf Office",
    service: "Security Guards (24/7)",
    startDate: "2025-05-15",
    endDate: "2026-05-14",
    value: "£156,000",
    status: "Draft",
  },
  {
    id: "WO-2025-0079",
    client: "Metro Building Management",
    location: "Victoria Tower",
    service: "CCTV Installation & Monitoring",
    startDate: "2025-06-01",
    endDate: "2025-12-31",
    value: "£42,500",
    status: "In Progress",
  },
  {
    id: "WO-2025-0080",
    client: "Citywide Properties",
    location: "Manchester Office Complex",
    service: "Access Control System",
    startDate: "2025-05-20",
    endDate: "2025-06-30",
    value: "£28,750",
    status: "On Hold",
  },
  {
    id: "WO-2025-0081",
    client: "Riverside Apartments",
    location: "Thames Riverside Blocks A-C",
    service: "Security Staff & Concierge",
    startDate: "2025-04-01",
    endDate: "2026-03-31",
    value: "£124,800",
    status: "In Progress",
  },
  {
    id: "WO-2025-0082",
    client: "Northern Rail Stations",
    location: "Leeds Central Station",
    service: "Mobile Patrol Services",
    startDate: "2025-03-15",
    endDate: "2025-09-14",
    value: "£36,400",
    status: "Completed",
  }
];

const getStatusBadge = (status: string) => {
  switch (status) {
    case "Draft":
      return <Badge className="bg-gray-500 hover:bg-gray-600">{status}</Badge>;
    case "In Progress":
      return <Badge className="bg-blue-500 hover:bg-blue-600">{status}</Badge>;
    case "On Hold":
      return <Badge className="bg-amber-500 hover:bg-amber-600">{status}</Badge>;
    case "Completed":
      return <Badge className="bg-green-500 hover:bg-green-600">{status}</Badge>;
    default:
      return <Badge>{status}</Badge>;
  }
};

interface WorkordersTableProps {
  filter: string;
  searchTerm: string;
  onEdit: (workorder: any) => void;
}

export function WorkordersTable({ filter, searchTerm, onEdit }: WorkordersTableProps) {
  const { toast } = useToast();
  
  // Filter workorders based on selected filter and search term
  const filteredWorkorders = mockWorkorders.filter(workorder => {
    // Filter by status
    if (filter !== "All Workorders" && !workorder.status.includes(filter.replace("Workorders", "").trim())) {
      return false;
    }
    
    // Filter by search term
    if (searchTerm && !Object.values(workorder).some(value => 
      String(value).toLowerCase().includes(searchTerm.toLowerCase())
    )) {
      return false;
    }
    
    return true;
  });
  
  const handleDelete = (id: string) => {
    toast({
      title: "Workorder Deleted",
      description: `Workorder ${id} has been deleted successfully.`,
      duration: 3000,
    });
  };
  
  const handleView = (id: string) => {
    toast({
      title: "Viewing Workorder Details",
      description: `Viewing details for workorder ${id}.`,
      duration: 3000,
    });
  };
  
  const handleDownload = (id: string) => {
    toast({
      title: "Downloading Workorder",
      description: `Downloading workorder ${id} as PDF.`,
      duration: 3000,
    });
  };
  
  const handleStatusChange = (id: string, newStatus: string) => {
    toast({
      title: "Status Updated",
      description: `Workorder ${id} status changed to ${newStatus}.`,
      duration: 3000,
    });
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-md shadow">
      <Table>
        <TableCaption>Active and completed workorders</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>Order #</TableHead>
            <TableHead>Client</TableHead>
            <TableHead className="hidden lg:table-cell">Service</TableHead>
            <TableHead className="hidden md:table-cell">Duration</TableHead>
            <TableHead>Value</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredWorkorders.length > 0 ? (
            filteredWorkorders.map((workorder) => (
              <TableRow key={workorder.id}>
                <TableCell className="font-medium">{workorder.id}</TableCell>
                <TableCell>
                  {workorder.client}
                  <div className="text-xs text-muted-foreground mt-1 hidden md:block">
                    {workorder.location}
                  </div>
                </TableCell>
                <TableCell className="hidden lg:table-cell">{workorder.service}</TableCell>
                <TableCell className="hidden md:table-cell">
                  {workorder.startDate} to {workorder.endDate}
                </TableCell>
                <TableCell>{workorder.value}</TableCell>
                <TableCell>{getStatusBadge(workorder.status)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleView(workorder.id)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleDownload(workorder.id)}
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                    {workorder.status !== "Completed" && (
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-green-500 hover:text-green-600"
                        onClick={() => handleStatusChange(workorder.id, "Completed")}
                      >
                        <CheckCircle className="h-4 w-4" />
                      </Button>
                    )}
                    {workorder.status !== "On Hold" && workorder.status !== "Completed" && (
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-amber-500 hover:text-amber-600"
                        onClick={() => handleStatusChange(workorder.id, "On Hold")}
                      >
                        <AlertCircle className="h-4 w-4" />
                      </Button>
                    )}
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => onEdit(workorder)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-red-500 hover:text-red-600" 
                      onClick={() => handleDelete(workorder.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-6">
                No workorders found matching your criteria
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}
