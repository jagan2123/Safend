
import { EnhancedButton as Button } from "@/components/ui/enhanced-button";
import { Eye, Edit, Trash2, Download, Send, CheckCircle, XCircle } from "lucide-react";
import { useToastWithSound } from "@/hooks/use-toast-with-sound";
import { SoundBus } from "@/services/SoundService";

interface QuotationActionProps {
  quotation: any;
  onEdit: (quotation: any) => void;
}

export function QuotationActionButtons({ quotation, onEdit }: QuotationActionProps) {
  const { toast } = useToastWithSound();
  
  const handleDelete = (id: string) => {
    SoundBus.play('delete');
    toast({
      title: "Quotation Deleted",
      description: `Quotation ${id} has been deleted successfully.`,
      duration: 3000,
      sound: 'delete'
    });
  };
  
  const handleView = (id: string) => {
    SoundBus.play('click');
    toast({
      title: "Viewing Quotation Details",
      description: `Viewing details for quotation ${id}.`,
      duration: 3000,
    });
  };
  
  const handleDownload = (id: string) => {
    SoundBus.play('download');
    toast({
      title: "Downloading Quotation",
      description: `Downloading quotation ${id} as PDF.`,
      duration: 3000,
      sound: 'download'
    });
  };
  
  const handleSend = (id: string, client: string) => {
    SoundBus.play('notification');
    toast({
      title: "Sending Quotation",
      description: `Sending quotation ${id} to ${client}.`,
      duration: 3000,
    });
  };
  
  const handleApprove = (id: string) => {
    SoundBus.play('success');
    toast.success({
      title: "Quotation Approved",
      description: `Quotation ${id} has been approved. You can now create a work order.`,
      duration: 3000,
    });
  };
  
  const handleReject = (id: string) => {
    SoundBus.play('error');
    toast.error({
      title: "Quotation Rejected",
      description: `Quotation ${id} has been rejected. The lead will be moved to follow-up.`,
      duration: 3000,
    });
  };

  return (
    <div className="flex justify-end gap-2">
      <Button 
        variant="ghost" 
        size="icon" 
        onClick={() => handleView(quotation.id)}
        soundEffect="click"
      >
        <Eye className="h-4 w-4" />
      </Button>
      <Button 
        variant="ghost" 
        size="icon" 
        onClick={() => handleDownload(quotation.id)}
        soundEffect="download"
      >
        <Download className="h-4 w-4" />
      </Button>
      <Button 
        variant="ghost" 
        size="icon"
        onClick={() => handleSend(quotation.id, quotation.client)}
        soundEffect="notification"
      >
        <Send className="h-4 w-4" />
      </Button>
      {quotation.status === "Pending" && (
        <>
          <Button 
            variant="ghost" 
            size="icon"
            className="text-green-500 hover:text-green-600"
            onClick={() => handleApprove(quotation.id)}
            soundEffect="success"
          >
            <CheckCircle className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            className="text-red-500 hover:text-red-600"
            onClick={() => handleReject(quotation.id)}
            soundEffect="error"
          >
            <XCircle className="h-4 w-4" />
          </Button>
        </>
      )}
      <Button 
        variant="ghost" 
        size="icon" 
        onClick={() => onEdit(quotation)}
        soundEffect="click"
      >
        <Edit className="h-4 w-4" />
      </Button>
      <Button 
        variant="ghost" 
        size="icon" 
        className="text-red-500 hover:text-red-600" 
        onClick={() => handleDelete(quotation.id)}
        soundEffect="delete"
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );
}
