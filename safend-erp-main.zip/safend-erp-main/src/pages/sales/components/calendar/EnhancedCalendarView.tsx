
import { useState } from "react";
import { Calendar, Views, dateFnsLocalizer } from "react-big-calendar";
import { format } from "date-fns";
import { parse } from "date-fns";
import { startOfWeek } from "date-fns";
import { getDay } from "date-fns";
import { enIN } from "date-fns/locale/en-IN";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import "react-big-calendar/lib/css/react-big-calendar.css";
import { CalendarEvent } from "./CalendarEvent";
import { EventDetailDialog } from "./EventDetailDialog";
import { CreateEventDialog } from "./CreateEventDialog";

// Setup the localizer for react-big-calendar
const locales = {
  "en-IN": enIN,
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

// Mock event data
const mockEvents = [
  {
    id: "1",
    title: "Client Meeting - Apex Corporate",
    start: new Date(2023, 5, 10, 10, 0),
    end: new Date(2023, 5, 10, 11, 30),
    type: "meeting",
    location: "Client Office",
    attendees: ["Raj Kumar", "Priya Singh"],
    description: "Quarterly review meeting with client",
    clientId: "CLI-001",
  },
  {
    id: "2",
    title: "Site Assessment - Industrial Park",
    start: new Date(2023, 5, 12, 9, 0),
    end: new Date(2023, 5, 12, 12, 0),
    type: "site-visit",
    location: "Industrial Park Ltd, Sector 3",
    attendees: ["Vikram Mehta"],
    description: "Initial site assessment for new contract",
    clientId: "CLI-008",
  },
  {
    id: "3",
    title: "Contract Renewal - Grand Hotel",
    start: new Date(2023, 5, 15, 14, 0),
    end: new Date(2023, 5, 15, 15, 0),
    type: "contract",
    location: "Virtual Meeting",
    attendees: ["Raj Kumar", "Anand Sharma"],
    description: "Contract renewal discussion for upcoming year",
    clientId: "CLI-019",
  },
  {
    id: "4",
    title: "PSARA License Renewal",
    start: new Date(2023, 6, 5, 0, 0),
    end: new Date(2023, 6, 5, 23, 59),
    type: "compliance",
    location: "Head Office",
    attendees: ["Admin Team"],
    description: "Annual PSARA license renewal deadline",
    clientId: null,
  },
  {
    id: "5",
    title: "Follow-up Call - Metro Residential",
    start: new Date(2023, 5, 11, 15, 30),
    end: new Date(2023, 5, 11, 16, 0),
    type: "follow-up",
    location: "Phone Call",
    attendees: ["Priya Singh"],
    description: "Follow up on quotation sent last week",
    clientId: "CLI-015",
  },
];

// Event type configurations for display
const eventTypes = {
  meeting: { color: "#4f46e5", icon: "Calendar" },
  "site-visit": { color: "#22c55e", icon: "MapPin" },
  contract: { color: "#f59e0b", icon: "FileText" },
  compliance: { color: "#ef4444", icon: "Clipboard" },
  "follow-up": { color: "#6366f1", icon: "Phone" },
};

export function EnhancedCalendarView() {
  const [view, setView] = useState("month");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [isCreateEventOpen, setIsCreateEventOpen] = useState(false);
  
  const handleViewChange = (newView: string) => {
    setView(newView);
  };
  
  const handleNavigate = (date: Date, view: string) => {
    setSelectedDate(date);
  };
  
  const handleSelectEvent = (event: any) => {
    setSelectedEvent(event);
    setIsEventModalOpen(true);
  };
  
  const handleSelectSlot = ({ start, end }: { start: Date; end: Date }) => {
    setSelectedEvent({ start, end });
    setIsCreateEventOpen(true);
  };
  
  const eventStyleGetter = (event: any) => {
    const eventType = event.type || "meeting";
    return {
      style: {
        backgroundColor: eventTypes[eventType as keyof typeof eventTypes]?.color || "#4f46e5",
        borderRadius: "4px",
      },
    };
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">Sales Calendar</h2>
          <p className="text-muted-foreground">
            Manage client meetings, site visits and important dates
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button onClick={() => setIsCreateEventOpen(true)} className="bg-safend-red hover:bg-red-700">
            Add Event
          </Button>
          
          <Select value={view} onValueChange={handleViewChange}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="View" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month">Month</SelectItem>
              <SelectItem value="week">Week</SelectItem>
              <SelectItem value="day">Day</SelectItem>
              <SelectItem value="agenda">Agenda</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Calendar Events</CardTitle>
              <CardDescription>Client meetings, contract deadlines and compliance dates</CardDescription>
            </div>
            
            <div className="flex items-center gap-2">
              <Tabs defaultValue="all" className="h-8">
                <TabsList>
                  <TabsTrigger value="all" className="h-8">All</TabsTrigger>
                  <TabsTrigger value="meetings" className="h-8">Meetings</TabsTrigger>
                  <TabsTrigger value="contracts" className="h-8">Contracts</TabsTrigger>
                  <TabsTrigger value="compliance" className="h-8">Compliance</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-[700px]">
            {/* Using react-big-calendar */}
            <Calendar
              localizer={localizer}
              events={mockEvents}
              startAccessor="start"
              endAccessor="end"
              view={view as any}
              onView={(newView) => handleViewChange(newView)}
              date={selectedDate}
              onNavigate={handleNavigate}
              selectable
              onSelectEvent={handleSelectEvent}
              onSelectSlot={handleSelectSlot}
              eventPropGetter={eventStyleGetter}
              components={{
                event: CalendarEvent,
              }}
              views={[Views.MONTH, Views.WEEK, Views.DAY, Views.AGENDA]}
            />
          </div>
        </CardContent>
      </Card>
      
      {/* Event detail dialog */}
      <EventDetailDialog
        isOpen={isEventModalOpen}
        onClose={() => setIsEventModalOpen(false)}
        event={selectedEvent}
        eventTypes={eventTypes}
      />
      
      {/* Create event dialog */}
      <CreateEventDialog
        isOpen={isCreateEventOpen}
        onClose={() => setIsCreateEventOpen(false)}
        initialEvent={selectedEvent}
        eventTypes={eventTypes}
      />
    </div>
  );
}
