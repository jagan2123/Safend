
import { Card } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";

interface SalesCalendarViewProps {
  filter: string;
}

// Mock data for calendar events
const events = [
  { 
    id: 1, 
    title: "Meeting with Summit Security", 
    date: new Date(2025, 4, 5), 
    type: "Meeting",
    contact: "John Smith"
  },
  { 
    id: 2, 
    title: "Call with Metro Building", 
    date: new Date(2025, 4, 7), 
    type: "Call",
    contact: "Sarah Johnson"
  },
  { 
    id: 3, 
    title: "Site visit at Riverside", 
    date: new Date(2025, 4, 10), 
    type: "Site Visit",
    contact: "Emma Wilson"
  },
  { 
    id: 4, 
    title: "Quote deadline for Northern Rail", 
    date: new Date(2025, 4, 12), 
    type: "Deadline",
    contact: "James Thompson"
  },
  { 
    id: 5, 
    title: "Follow-up with Citywide", 
    date: new Date(2025, 4, 15), 
    type: "Follow-up",
    contact: "Michael Davis"
  },
  { 
    id: 6, 
    title: "Contract renewal with Summit", 
    date: new Date(2025, 4, 20), 
    type: "Deadline",
    contact: "John Smith"
  }
];

export function SalesCalendarView({ filter }: SalesCalendarViewProps) {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [selectedDateEvents, setSelectedDateEvents] = useState<any[]>([]);
  
  // Filter events based on the selected filter
  const filteredEvents = events.filter(event => {
    if (filter === "All Events") {
      return true;
    } else {
      return event.type.toLowerCase() === filter.toLowerCase().replace("s", "");
    }
  });
  
  // Find events for the selected date
  const handleSelect = (selectedDate: Date | undefined) => {
    setDate(selectedDate);
    if (selectedDate) {
      const eventsOnDay = filteredEvents.filter(event => 
        event.date.getDate() === selectedDate.getDate() &&
        event.date.getMonth() === selectedDate.getMonth() &&
        event.date.getFullYear() === selectedDate.getFullYear()
      );
      setSelectedDateEvents(eventsOnDay);
    } else {
      setSelectedDateEvents([]);
    }
  };
  
  // Function to highlight dates with events
  const isDayWithEvent = (day: Date) => {
    return filteredEvents.some(event => 
      event.date.getDate() === day.getDate() &&
      event.date.getMonth() === day.getMonth() &&
      event.date.getFullYear() === day.getFullYear()
    );
  };
  
  // Get event type badge
  const getEventTypeBadge = (type: string) => {
    switch (type) {
      case "Meeting":
        return <Badge className="bg-blue-500 hover:bg-blue-600">{type}</Badge>;
      case "Call":
        return <Badge className="bg-green-500 hover:bg-green-600">{type}</Badge>;
      case "Site Visit":
        return <Badge className="bg-purple-500 hover:bg-purple-600">{type}</Badge>;
      case "Deadline":
        return <Badge className="bg-red-500 hover:bg-red-600">{type}</Badge>;
      case "Follow-up":
        return <Badge className="bg-amber-500 hover:bg-amber-600">{type}</Badge>;
      default:
        return <Badge>{type}</Badge>;
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="p-4 col-span-1">
        <Calendar
          mode="single"
          selected={date}
          onSelect={handleSelect}
          className="rounded-md border"
          modifiers={{
            event: (date) => isDayWithEvent(date)
          }}
          modifiersStyles={{
            event: { fontWeight: 'bold', textDecoration: 'underline', color: '#ea384c' }
          }}
        />
        <div className="mt-4">
          <h4 className="font-medium mb-2">Calendar Legend</h4>
          <div className="flex flex-wrap gap-2">
            <Badge className="bg-blue-500 hover:bg-blue-600">Meeting</Badge>
            <Badge className="bg-green-500 hover:bg-green-600">Call</Badge>
            <Badge className="bg-purple-500 hover:bg-purple-600">Site Visit</Badge>
            <Badge className="bg-red-500 hover:bg-red-600">Deadline</Badge>
            <Badge className="bg-amber-500 hover:bg-amber-600">Follow-up</Badge>
          </div>
        </div>
      </Card>
      
      <Card className="p-4 col-span-1 lg:col-span-2">
        <h3 className="text-lg font-medium mb-4">
          {date ? `Events on ${date.toLocaleDateString('en-GB')}` : "Select a date"}
        </h3>
        
        {selectedDateEvents.length > 0 ? (
          <div className="space-y-4">
            {selectedDateEvents.map(event => (
              <Card key={event.id} className="p-3 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium">{event.title}</h4>
                    <p className="text-sm text-muted-foreground">Contact: {event.contact}</p>
                  </div>
                  {getEventTypeBadge(event.type)}
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            {date ? "No events scheduled for this date" : "Please select a date from the calendar"}
          </div>
        )}
        
        <div className="mt-6">
          <h3 className="text-lg font-medium mb-4">Upcoming Events</h3>
          <div className="space-y-3">
            {filteredEvents
              .filter(event => event.date >= new Date())
              .sort((a, b) => a.date.getTime() - b.date.getTime())
              .slice(0, 5)
              .map(event => (
                <div key={event.id} className="flex justify-between items-center border-b pb-2">
                  <div>
                    <p className="font-medium">{event.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {event.date.toLocaleDateString('en-GB')} • {event.contact}
                    </p>
                  </div>
                  {getEventTypeBadge(event.type)}
                </div>
              ))
            }
          </div>
        </div>
      </Card>
    </div>
  );
}
