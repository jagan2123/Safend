
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, Edit, Trash2, FileSignature, Printer, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Mock data for agreements
const mockAgreements = [
  {
    id: 1,
    clientName: "Summit Security Limited",
    contactPerson: "John Smith",
    quotationRef: "QT-2025-001",
    signedOn: "2025-04-20",
    validUntil: "2026-04-19",
    status: "Active",
    value: "₹12,50,000",
  },
  {
    id: 2,
    clientName: "Metro Building Management",
    contactPerson: "Sarah Johnson",
    quotationRef: "QT-2025-008",
    signedOn: "2025-04-15",
    validUntil: "2027-04-14",
    status: "Active",
    value: "₹24,75,000",
  },
  {
    id: 3,
    clientName: "Citywide Properties",
    contactPerson: "Michael Davis",
    quotationRef: "QT-2025-012",
    signedOn: "",
    validUntil: "",
    status: "Draft",
    value: "₹36,00,000",
  },
  {
    id: 4,
    clientName: "Riverside Apartments",
    contactPerson: "Emma Wilson",
    quotationRef: "QT-2024-089",
    signedOn: "2024-10-10",
    validUntil: "2025-10-09",
    status: "Active",
    value: "₹18,30,000",
  },
  {
    id: 5,
    clientName: "Northern Rail Stations",
    contactPerson: "James Thompson",
    quotationRef: "QT-2024-067",
    signedOn: "2024-08-12",
    validUntil: "2025-08-11",
    status: "Expired",
    value: "₹9,45,000",
  },
  {
    id: 6,
    clientName: "Westside Mall",
    contactPerson: "Lisa Chen",
    quotationRef: "QT-2025-015",
    signedOn: "2025-04-28",
    validUntil: "2026-04-27",
    status: "Signed",
    value: "₹16,80,000",
  }
];

const getStatusBadge = (status: string) => {
  switch (status) {
    case "Draft":
      return <Badge className="bg-gray-500 hover:bg-gray-600">{status}</Badge>;
    case "Signed":
      return <Badge className="bg-green-500 hover:bg-green-600">{status}</Badge>;
    case "Active":
      return <Badge className="bg-safend-red hover:bg-red-700">{status}</Badge>;
    case "Expired":
      return <Badge className="bg-gray-500 hover:bg-gray-600">{status}</Badge>;
    case "Terminated":
      return <Badge className="bg-black hover:bg-gray-900 text-white">{status}</Badge>;
    default:
      return <Badge>{status}</Badge>;
  }
};

interface AgreementsTableProps {
  filter: string;
  searchTerm: string;
  onEdit: (agreement: any) => void;
}

export function AgreementsTable({ filter, searchTerm, onEdit }: AgreementsTableProps) {
  const { toast } = useToast();
  
  // Filter agreements based on selected filter and search term
  const filteredAgreements = mockAgreements.filter(agreement => {
    // Filter by status
    if (filter !== "All Agreements" && !agreement.status.includes(filter)) {
      return false;
    }
    
    // Filter by search term
    if (searchTerm && !Object.values(agreement).some(value => 
      String(value).toLowerCase().includes(searchTerm.toLowerCase())
    )) {
      return false;
    }
    
    return true;
  });
  
  const handleDelete = (id: number) => {
    toast({
      title: "Agreement Deleted",
      description: `Agreement #${id} has been deleted successfully.`,
      duration: 3000,
    });
  };
  
  const handleView = (id: number) => {
    toast({
      title: "Viewing Agreement",
      description: `Viewing details for agreement #${id}.`,
      duration: 3000,
    });
  };
  
  const handleSign = (id: number) => {
    toast({
      title: "Electronic Signature",
      description: `Preparing electronic signature process for agreement #${id}.`,
      duration: 3000,
    });
  };
  
  const handlePrint = (id: number) => {
    toast({
      title: "Print Agreement",
      description: `Preparing agreement #${id} for printing.`,
      duration: 3000,
    });
  };
  
  const handleSend = (id: number) => {
    toast({
      title: "Send Agreement",
      description: `Preparing to send agreement #${id} via email or post.`,
      duration: 3000,
    });
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-md shadow">
      <Table>
        <TableCaption>List of agreements and contracts</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>Client</TableHead>
            <TableHead className="hidden md:table-cell">Quote Ref.</TableHead>
            <TableHead className="hidden lg:table-cell">Signed On</TableHead>
            <TableHead className="hidden md:table-cell">Valid Until</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="hidden lg:table-cell">Value</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredAgreements.length > 0 ? (
            filteredAgreements.map((agreement) => (
              <TableRow key={agreement.id}>
                <TableCell className="font-medium">
                  {agreement.clientName}
                  <div className="text-xs text-muted-foreground mt-1">
                    {agreement.contactPerson}
                  </div>
                </TableCell>
                <TableCell className="hidden md:table-cell">{agreement.quotationRef}</TableCell>
                <TableCell className="hidden lg:table-cell">
                  {agreement.signedOn || "Not signed"}
                </TableCell>
                <TableCell className="hidden md:table-cell">
                  {agreement.validUntil || "N/A"}
                </TableCell>
                <TableCell>{getStatusBadge(agreement.status)}</TableCell>
                <TableCell className="hidden lg:table-cell">{agreement.value}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleView(agreement.id)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    
                    {agreement.status === "Draft" && (
                      <Button 
                        variant="ghost" 
                        size="icon"
                        className="text-safend-red hover:text-red-700"
                        onClick={() => handleSign(agreement.id)}
                      >
                        <FileSignature className="h-4 w-4" />
                      </Button>
                    )}
                    
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handlePrint(agreement.id)}
                    >
                      <Printer className="h-4 w-4" />
                    </Button>
                    
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleSend(agreement.id)}
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                    
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => onEdit(agreement)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-safend-red hover:text-red-700" 
                      onClick={() => handleDelete(agreement.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-6">
                No agreements found matching your criteria
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}
