
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { getStatusBadge, getPricingTypeBadge } from "./QuotationStatusBadge";
import { QuotationActionButtons } from "./QuotationActionButtons";

// Extended mock data for security agency quotations
const mockQuotations = [
  {
    id: "QT-2025-0123",
    client: "Summit Security Limited",
    service: "Unarmed Guards (2) - Day Shift, Armed Guards (4) - Night Shift",
    serviceDetails: [
      { type: "Unarmed Guard", quantity: 2, shift: "Day (8 Hours)", rate: "₹18,000/month" },
      { type: "Armed Guard", quantity: 4, shift: "Night (8 Hours)", rate: "₹22,000/month" }
    ],
    pricingType: "Minimum Wages",
    amount: "₹1,25,000",
    status: "Pending",
    date: "2025-05-01",
    validUntil: "2025-06-01",
    contactPerson: "Rajesh Kumar",
    contactPhone: "+91 98765 43210"
  },
  {
    id: "QT-2025-0124",
    client: "Metro Building Management",
    service: "CCTV Installation & Monitoring, Security Supervisor (1)",
    serviceDetails: [
      { type: "CCTV Installation", quantity: 12, shift: "N/A", rate: "₹4,500/camera" },
      { type: "Security Supervisor", quantity: 1, shift: "General (12 Hours)", rate: "₹28,000/month" }
    ],
    pricingType: "Customized",
    amount: "₹38,500",
    status: "Approved",
    date: "2025-04-28",
    validUntil: "2025-05-28",
    contactPerson: "Priya Sharma",
    contactPhone: "+91 87654 32109"
  },
  {
    id: "QT-2025-0125",
    client: "Citywide Properties",
    service: "Access Control System, Bouncers (2) - Event Security",
    serviceDetails: [
      { type: "Access Control System", quantity: 5, shift: "N/A", rate: "₹8,500/door" },
      { type: "Bouncer", quantity: 2, shift: "Event (6 Hours)", rate: "₹2,000/day" }
    ],
    pricingType: "Customized",
    amount: "₹67,300",
    status: "Rejected",
    date: "2025-04-25",
    validUntil: "2025-05-25",
    contactPerson: "Amit Patel",
    contactPhone: "+91 76543 21098"
  },
  {
    id: "QT-2025-0126",
    client: "Riverside Apartments",
    service: "Security Staff (3) & Concierge (1)",
    serviceDetails: [
      { type: "Unarmed Guard", quantity: 3, shift: "Rotational (8 Hours)", rate: "₹17,500/month" },
      { type: "Concierge", quantity: 1, shift: "Day (12 Hours)", rate: "₹22,000/month" }
    ],
    pricingType: "Minimum Wages",
    amount: "₹98,700",
    status: "Pending",
    date: "2025-04-23",
    validUntil: "2025-05-23",
    contactPerson: "Neha Singh",
    contactPhone: "+91 65432 10987"
  },
  {
    id: "QT-2025-0127",
    client: "Northern Rail Stations",
    service: "Mobile Patrol Services, Armed Guards (2)",
    serviceDetails: [
      { type: "Mobile Patrol", quantity: 1, shift: "Night (8 Hours)", rate: "₹25,000/month" },
      { type: "Armed Guard", quantity: 2, shift: "Night (8 Hours)", rate: "₹23,000/month" }
    ],
    pricingType: "Minimum Wages",
    amount: "₹45,900",
    status: "Expired",
    date: "2025-03-15",
    validUntil: "2025-04-15",
    contactPerson: "Vijay Malhotra",
    contactPhone: "+91 54321 09876"
  }
];

interface QuotationsTableProps {
  filter: string;
  searchTerm: string;
  onEdit: (quotation: any) => void;
}

export function QuotationsTable({ filter, searchTerm, onEdit }: QuotationsTableProps) {
  // Filter quotations based on selected filter and search term
  const filteredQuotations = mockQuotations.filter(quotation => {
    // Filter by status
    if (filter !== "All Quotations" && !quotation.status.includes(filter.replace("Quotations", "").trim())) {
      return false;
    }
    
    // Filter by search term
    if (searchTerm && !Object.values(quotation).some(value => 
      String(value).toLowerCase().includes(searchTerm.toLowerCase())
    )) {
      return false;
    }
    
    return true;
  });

  return (
    <div className="bg-white dark:bg-gray-800 rounded-md shadow">
      <Table>
        <TableCaption>List of quotations sent to clients</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>Quote #</TableHead>
            <TableHead>Client</TableHead>
            <TableHead className="hidden md:table-cell">Service Details</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="hidden lg:table-cell">Pricing</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredQuotations.length > 0 ? (
            filteredQuotations.map((quotation) => (
              <TableRow key={quotation.id}>
                <TableCell className="font-medium">{quotation.id}</TableCell>
                <TableCell>
                  {quotation.client}
                  <div className="text-xs text-muted-foreground mt-1">
                    {quotation.contactPerson}
                  </div>
                </TableCell>
                <TableCell className="hidden md:table-cell max-w-[200px]">
                  <div className="truncate">{quotation.service}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Valid until: {quotation.validUntil}
                  </div>
                </TableCell>
                <TableCell>{quotation.amount}</TableCell>
                <TableCell>{getStatusBadge(quotation.status)}</TableCell>
                <TableCell className="hidden lg:table-cell">
                  {getPricingTypeBadge(quotation.pricingType)}
                </TableCell>
                <TableCell className="text-right">
                  <QuotationActionButtons quotation={quotation} onEdit={onEdit} />
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-6">
                No quotations found matching your criteria
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}
