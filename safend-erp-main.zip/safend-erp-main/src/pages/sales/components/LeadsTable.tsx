
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, Edit, Trash2, Phone, Mail, FileText, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Mock data for leads
const mockLeads = [
  {
    id: 1,
    name: "Summit Security Limited",
    contact: "John Smith",
    phone: "+91 98765 43210",
    email: "john@summitsecurity.com",
    status: "New Lead",
    value: "₹1,25,000",
    source: "Website",
    date: "2025-05-01",
    dutyType: "8H",
    services: {
      manned_guarding: true,
      reception: false,
      cctv_monitoring: true,
      event_security: false,
      mobile_patrol: false,
      alarm_response: false
    }
  },
  {
    id: 2,
    name: "Metro Building Management",
    contact: "Sarah Johnson",
    phone: "+91 87654 32109",
    email: "sarah@metrobm.com",
    status: "Qualified Lead",
    value: "₹2,47,500",
    source: "Referral",
    date: "2025-04-28",
    dutyType: "12H",
    services: {
      manned_guarding: true,
      reception: true,
      cctv_monitoring: false,
      event_security: false,
      mobile_patrol: true,
      alarm_response: false
    }
  },
  {
    id: 3,
    name: "Citywide Properties",
    contact: "Michael Davis",
    phone: "+91 76543 21098",
    email: "mdavis@citywide.com",
    status: "Opportunity",
    value: "₹3,60,000",
    source: "Cold Call",
    date: "2025-04-25",
    dutyType: "12H",
    services: {
      manned_guarding: true,
      reception: false,
      cctv_monitoring: true,
      event_security: false,
      mobile_patrol: true,
      alarm_response: true
    }
  },
  {
    id: 4,
    name: "Riverside Apartments",
    contact: "Emma Wilson",
    phone: "+91 65432 10987",
    email: "emma@riverside-apts.com",
    status: "Closed Won",
    value: "₹1,83,000",
    source: "Exhibition",
    date: "2025-04-20",
    dutyType: "8H",
    services: {
      manned_guarding: true,
      reception: false,
      cctv_monitoring: false,
      event_security: false,
      mobile_patrol: false,
      alarm_response: false
    }
  },
  {
    id: 5,
    name: "Northern Rail Stations",
    contact: "James Thompson",
    phone: "+91 54321 09876",
    email: "james@northern-rail.co.uk",
    status: "Closed Lost",
    value: "₹4,20,000",
    source: "LinkedIn",
    date: "2025-04-18",
    dutyType: "12H",
    services: {
      manned_guarding: true,
      reception: false,
      cctv_monitoring: true,
      event_security: false,
      mobile_patrol: true,
      alarm_response: true
    }
  }
];

const getStatusBadge = (status: string) => {
  switch (status) {
    case "New Lead":
      return <Badge className="bg-blue-500 hover:bg-blue-600">{status}</Badge>;
    case "Qualified Lead":
      return <Badge className="bg-purple-500 hover:bg-purple-600">{status}</Badge>;
    case "Opportunity":
      return <Badge className="bg-amber-500 hover:bg-amber-600">{status}</Badge>;
    case "Closed Won":
      return <Badge className="bg-green-500 hover:bg-green-600">{status}</Badge>;
    case "Closed Lost":
      return <Badge className="bg-gray-500 hover:bg-gray-600">{status}</Badge>;
    default:
      return <Badge>{status}</Badge>;
  }
};

interface LeadsTableProps {
  filter: string;
  searchTerm: string;
  onEdit: (lead: any) => void;
  onClientSelect?: (client: any) => void; // Added this property as optional
}

export function LeadsTable({ filter, searchTerm, onEdit, onClientSelect }: LeadsTableProps) {
  const { toast } = useToast();
  
  // Filter leads based on selected filter and search term
  const filteredLeads = mockLeads.filter(lead => {
    // Filter by status
    if (filter !== "All Leads" && !lead.status.includes(filter.replace("Leads", "Lead").trim())) {
      return false;
    }
    
    // Filter by search term
    if (searchTerm && !Object.values(lead).some(value => 
      typeof value === 'object' 
        ? JSON.stringify(value).toLowerCase().includes(searchTerm.toLowerCase())
        : String(value).toLowerCase().includes(searchTerm.toLowerCase())
    )) {
      return false;
    }
    
    return true;
  });
  
  const handleDelete = (id: number) => {
    toast({
      title: "Lead Deleted",
      description: `Lead #${id} has been deleted successfully.`,
      duration: 3000,
    });
  };
  
  const handleView = (id: number) => {
    toast({
      title: "Viewing Lead Details",
      description: `Viewing details for lead #${id}.`,
      duration: 3000,
    });
  };
  
  const handleContact = (method: string, contact: string) => {
    toast({
      title: `Contact via ${method}`,
      description: `Contacting ${contact} via ${method.toLowerCase()}.`,
      duration: 3000,
    });
  };
  
  const handleCreateQuotation = (lead: any) => {
    toast({
      title: "Create Quotation",
      description: `Creating quotation for ${lead.name}.`,
      duration: 3000,
    });
  };
  
  const handleScheduleFollowup = (lead: any) => {
    toast({
      title: "Schedule Follow-up",
      description: `Scheduling follow-up with ${lead.name}.`,
      duration: 3000,
    });
  };
  
  // Format services for display
  const formatServices = (services: Record<string, boolean>) => {
    const activeServices = Object.entries(services)
      .filter(([_, active]) => active)
      .map(([service]) => service.replace('_', ' '));
    
    return activeServices.length > 0 
      ? activeServices.map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(', ')
      : 'None';
  };

  // Handle clicking on client/lead row or view button
  const handleClientSelect = (lead: any) => {
    if (onClientSelect) {
      onClientSelect(lead);
    } else {
      handleView(lead.id);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-md shadow">
      <Table>
        <TableCaption>List of leads and opportunities</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>Client</TableHead>
            <TableHead>Contact Person</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="hidden md:table-cell">Value</TableHead>
            <TableHead className="hidden lg:table-cell">Services</TableHead>
            <TableHead className="hidden md:table-cell">Duty Type</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredLeads.length > 0 ? (
            filteredLeads.map((lead) => (
              <TableRow 
                key={lead.id} 
                className={onClientSelect ? "cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700" : ""}
                onClick={onClientSelect ? () => handleClientSelect(lead) : undefined}
              >
                <TableCell className="font-medium">{lead.name}</TableCell>
                <TableCell>
                  {lead.contact}
                  <div className="flex gap-2 mt-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-7 w-7" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleContact("Phone", lead.contact);
                      }}
                    >
                      <Phone className="h-3.5 w-3.5" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-7 w-7" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleContact("Email", lead.contact);
                      }}
                    >
                      <Mail className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </TableCell>
                <TableCell>{getStatusBadge(lead.status)}</TableCell>
                <TableCell className="hidden md:table-cell">{lead.value}</TableCell>
                <TableCell className="hidden lg:table-cell">
                  <span className="text-sm">{formatServices(lead.services)}</span>
                </TableCell>
                <TableCell className="hidden md:table-cell">
                  <Badge variant="outline">
                    {lead.dutyType === "8H" ? "8 Hour Shift" : "12 Hour Shift"}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleView(lead.id);
                      }}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    
                    {(lead.status === "Qualified Lead" || lead.status === "Opportunity") && (
                      <Button 
                        variant="ghost" 
                        size="icon"
                        className="text-green-500 hover:text-green-600"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCreateQuotation(lead);
                        }}
                      >
                        <FileText className="h-4 w-4" />
                      </Button>
                    )}
                    
                    {(lead.status === "New Lead" || lead.status === "Qualified Lead" || lead.status === "Opportunity") && (
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleScheduleFollowup(lead);
                        }}
                      >
                        <MessageSquare className="h-4 w-4" />
                      </Button>
                    )}
                    
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={(e) => {
                        e.stopPropagation();
                        onEdit(lead);
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-red-500 hover:text-red-600" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(lead.id);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-6">
                No leads found matching your criteria
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}
