
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CashAdvance } from '@/services/security/SecurityCashAdvanceService';

interface SummaryStatsProps {
  advances: CashAdvance[] | undefined;
  categorySummary: Record<string, { 
    count?: number; 
    totalAmount?: number; 
    settledAmount?: number; 
    outstandingAmount?: number;
  }>;
}

export function SummaryStats({ advances, categorySummary }: SummaryStatsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Total Outstanding</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            ₹{Object.values(categorySummary || {})
              .reduce((sum, data: any) => sum + (data.outstandingAmount || 0), 0)
              .toLocaleString()}
          </div>
          <p className="text-xs text-muted-foreground">
            Across {advances?.length || 0} advances
          </p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Overdue Settlements</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-red-500">
            ₹{advances?.filter(a => a.status === 'disbursed' && new Date(a.settlementDueDate || '') < new Date())
              .reduce((sum, a) => sum + (a.balanceAmount || 0), 0)
              .toLocaleString()}
          </div>
          <p className="text-xs text-muted-foreground">
            {advances?.filter(a => a.status === 'disbursed' && new Date(a.settlementDueDate || '') < new Date()).length || 0} overdue advances
          </p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">This Month</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            ₹{advances?.filter(a => {
                const requestDate = new Date(a.requestDate);
                const now = new Date();
                return requestDate.getMonth() === now.getMonth() && requestDate.getFullYear() === now.getFullYear();
              })
              .reduce((sum, a) => sum + a.amount, 0)
              .toLocaleString()}
          </div>
          <p className="text-xs text-muted-foreground">
            vs ₹62,000 last month
          </p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Settlement Rate</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {Math.round(
              (Object.values(categorySummary || {}).reduce((sum, data: any) => sum + (data.settledAmount || 0), 0) / 
              (Object.values(categorySummary || {}).reduce((sum, data: any) => sum + (data.totalAmount || 0), 0) || 1)
              * 100
            )}%
          </div>
          <p className="text-xs text-muted-foreground">
            Of total advances settled
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
