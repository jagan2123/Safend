
import { useState, createContext, useContext, ReactNode } from 'react';
import { ExpenseForm } from './ExpenseForm';
import { InvoiceForm } from './InvoiceForm';
import { TransactionForm } from './TransactionForm';
import { useToast } from '@/hooks/use-toast';

// Define types for the forms context
interface FormsContextType {
  openExpenseForm: () => void;
  openInvoiceForm: () => void;
  openTransactionForm: () => void;
  closeAllForms: () => void;
}

// Create a context for the forms
const FormsContext = createContext<FormsContextType | undefined>(undefined);

// Provider component
export function FormsProvider({ children }: { children: ReactNode }) {
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [showInvoiceForm, setShowInvoiceForm] = useState(false);
  const [showTransactionForm, setShowTransactionForm] = useState(false);
  const { toast } = useToast();

  const openExpenseForm = () => {
    closeAllForms();
    setShowExpenseForm(true);
    toast({
      title: "Expense Form",
      description: "Add a new expense record",
    });
  };

  const openInvoiceForm = () => {
    closeAllForms();
    setShowInvoiceForm(true);
    toast({
      title: "Invoice Form",
      description: "Create a new invoice",
    });
  };

  const openTransactionForm = () => {
    closeAllForms();
    setShowTransactionForm(true);
    toast({
      title: "Transaction Form",
      description: "Record a new transaction",
    });
  };

  const closeAllForms = () => {
    setShowExpenseForm(false);
    setShowInvoiceForm(false);
    setShowTransactionForm(false);
  };

  return (
    <FormsContext.Provider
      value={{
        openExpenseForm,
        openInvoiceForm,
        openTransactionForm,
        closeAllForms,
      }}
    >
      {children}
      
      {/* Forms rendered at the component level, shown/hidden as needed */}
      <ExpenseForm isOpen={showExpenseForm} onClose={() => setShowExpenseForm(false)} />
      <InvoiceForm isOpen={showInvoiceForm} onClose={() => setShowInvoiceForm(false)} />
      <TransactionForm isOpen={showTransactionForm} onClose={() => setShowTransactionForm(false)} />
    </FormsContext.Provider>
  );
}

// Custom hook for consuming the forms context
export function useFormsController() {
  const context = useContext(FormsContext);
  if (context === undefined) {
    throw new Error('useFormsController must be used within a FormsProvider');
  }
  return context;
}

// Export the old component for backward compatibility
export function FormsController() {
  return null; // This component is deprecated, use FormsProvider and useFormsController instead
}
