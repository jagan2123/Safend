
import { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { useAccountsContext } from '@/context/AccountsContext';
import { useAccountsMutation } from '@/hooks/accounts/useAccountsData';
import { AccountsService, Invoice } from '@/services/accounts/AccountsService';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format, addDays } from 'date-fns';
import { Calendar as CalendarIcon } from 'lucide-react';
import { cn } from "@/lib/utils";

const invoiceFormSchema = z.object({
  clientName: z.string().min(3, { message: "Client name is required" }),
  clientId: z.string().optional(),
  invoiceNumber: z.string().min(1, { message: "Invoice number is required" }),
  issueDate: z.date({ required_error: "Issue date is required" }),
  dueDate: z.date({ required_error: "Due date is required" }),
  amount: z.coerce.number().min(1, { message: "Amount must be greater than 0" }),
  gstApplicable: z.boolean().default(true),
  gstAmount: z.coerce.number().optional(),
  eInvoiceApplicable: z.boolean().default(false),
  description: z.string().min(5, { message: "Description is required" }).max(500),
  type: z.string({ required_error: "Invoice type is required" }),
});

type InvoiceFormValues = z.infer<typeof invoiceFormSchema>;

interface InvoiceFormProps {
  isOpen: boolean;
  onClose: () => void;
}

export function InvoiceForm({ isOpen, onClose }: InvoiceFormProps) {
  const { toast } = useToast();
  const { selectedBranch } = useAccountsContext();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Generate default invoice number (in real app, this would come from API)
  const generateInvoiceNumber = () => {
    const prefix = "INV";
    const date = new Date();
    const year = date.getFullYear().toString().slice(2);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `${prefix}-${year}${month}-${random}`;
  };
  
  const form = useForm<InvoiceFormValues>({
    resolver: zodResolver(invoiceFormSchema),
    defaultValues: {
      clientName: "",
      clientId: "",
      invoiceNumber: generateInvoiceNumber(),
      issueDate: new Date(),
      dueDate: addDays(new Date(), 30),
      amount: undefined,
      gstApplicable: true,
      gstAmount: undefined,
      eInvoiceApplicable: false,
      description: "",
      type: "service",
    },
  });
  
  // Watch values for calculations
  const amount = form.watch("amount") || 0;
  const gstApplicable = form.watch("gstApplicable");
  
  // Calculate GST when amount or GST applicability changes
  const calculateGST = (amount: number, applicable: boolean) => {
    if (!applicable || amount <= 0) return 0;
    return amount * 0.18; // 18% GST
  };
  
  // Update GST amount when amount or GST applicability changes
  useState(() => {
    const gstAmount = calculateGST(amount, gstApplicable);
    form.setValue("gstAmount", gstAmount);
  });
  
  // Use the mutation hook for creating invoices
  const { mutate: createInvoice } = useAccountsMutation(
    (data) => AccountsService.createInvoice({
      ...data,
      branchId: selectedBranch || "main-branch",
      totalAmount: data.amount + (data.gstAmount || 0),
    }),
    "Invoice created successfully",
    "Failed to create invoice"
  );
  
  const onSubmit = async (values: InvoiceFormValues) => {
    setIsSubmitting(true);
    try {
      // Calculate total amount including GST
      const gstAmount = values.gstApplicable ? calculateGST(values.amount, true) : 0;
      const totalAmount = values.amount + gstAmount;
      
      await createInvoice({
        ...values,
        gstAmount: gstAmount,
        totalAmount: totalAmount,
        issueDate: values.issueDate.toISOString(),
        dueDate: values.dueDate.toISOString(),
      });
      
      form.reset();
      onClose();
    } catch (error) {
      console.error("Error creating invoice:", error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Create New Invoice</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="clientName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Client Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter client name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="invoiceNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Invoice Number</FormLabel>
                    <FormControl>
                      <Input {...field} readOnly />
                    </FormControl>
                    <FormDescription>Auto-generated invoice number</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="issueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Issue Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Due Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                          disabled={(date) => date < new Date()}
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (₹)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="Enter amount" 
                        {...field} 
                        onChange={(e) => {
                          field.onChange(e);
                          const value = parseFloat(e.target.value);
                          if (!isNaN(value)) {
                            const gstAmount = calculateGST(value, form.getValues("gstApplicable"));
                            form.setValue("gstAmount", gstAmount);
                          }
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Invoice Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select invoice type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="service">Service</SelectItem>
                        <SelectItem value="product">Product</SelectItem>
                        <SelectItem value="recurring">Recurring</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="gstApplicable"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between p-4 border rounded-lg">
                    <div className="space-y-0.5">
                      <FormLabel>GST Applicable</FormLabel>
                      <FormDescription>
                        Apply 18% GST to this invoice
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={(checked) => {
                          field.onChange(checked);
                          const gstAmount = calculateGST(form.getValues("amount"), checked);
                          form.setValue("gstAmount", gstAmount);
                        }}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="eInvoiceApplicable"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between p-4 border rounded-lg">
                    <div className="space-y-0.5">
                      <FormLabel>e-Invoice Required</FormLabel>
                      <FormDescription>
                        Generate e-Invoice for this transaction
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Enter invoice details"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Summary section */}
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <h4 className="text-sm font-medium mb-2">Invoice Summary</h4>
              <div className="flex justify-between text-sm">
                <span>Base Amount:</span>
                <span>₹{amount.toFixed(2)}</span>
              </div>
              {gstApplicable && (
                <div className="flex justify-between text-sm mt-1">
                  <span>GST (18%):</span>
                  <span>₹{calculateGST(amount, gstApplicable).toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-md font-bold mt-2 pt-2 border-t">
                <span>Total Amount:</span>
                <span>₹{(amount + calculateGST(amount, gstApplicable)).toFixed(2)}</span>
              </div>
            </div>
            
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Creating...' : 'Create Invoice'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
