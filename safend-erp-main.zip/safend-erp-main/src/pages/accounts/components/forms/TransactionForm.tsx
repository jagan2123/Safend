
import { useState, useEffect } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useAccountsContext } from '@/context/AccountsContext';
import { useAccountsData, useAccountsMutation } from '@/hooks/accounts/useAccountsData';
import { AccountsService, BankAccount, AccountTransaction } from '@/services/accounts/AccountsService';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { cn } from "@/lib/utils";

const transactionFormSchema = z.object({
  accountId: z.string().min(1, { message: "Please select an account" }),
  type: z.enum(["income", "expense", "transfer"]),
  amount: z.coerce.number().min(0.01, { message: "Amount must be greater than 0" }),
  date: z.date({ required_error: "Date is required" }),
  description: z.string().min(3, { message: "Description is required" }),
  reference: z.string().optional(),
  category: z.string().min(1, { message: "Category is required" }),
});

type TransactionFormValues = z.infer<typeof transactionFormSchema>;

interface TransactionFormProps {
  isOpen: boolean;
  onClose: () => void;
}

// Mock implementation for creating a transaction (will be replaced with actual API)
const createTransaction = async (transaction: any): Promise<AccountTransaction> => {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        id: `tr-${Date.now()}`,
        ...transaction,
        status: "completed",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }, 500);
  });
};

export function TransactionForm({ isOpen, onClose }: TransactionFormProps) {
  const { toast } = useToast();
  const { selectedBranch } = useAccountsContext();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Fetch bank accounts
  const { data: bankAccounts, isLoading: isLoadingAccounts } = useAccountsData(
    () => AccountsService.getBankAccounts({ branchId: selectedBranch || undefined }),
    [selectedBranch],
    []
  );
  
  const form = useForm<TransactionFormValues>({
    resolver: zodResolver(transactionFormSchema),
    defaultValues: {
      accountId: "",
      type: "income",
      amount: undefined,
      date: new Date(),
      description: "",
      reference: "",
      category: "",
    },
  });
  
  // Set up income/expense categories based on transaction type
  const [categories, setCategories] = useState<string[]>([]);
  const transactionType = form.watch("type");
  
  useEffect(() => {
    if (transactionType === "income") {
      setCategories([
        "Sales",
        "Services",
        "Investment",
        "Interest",
        "Refund",
        "Other Income"
      ]);
    } else if (transactionType === "expense") {
      setCategories([
        "Rent",
        "Utilities",
        "Salary",
        "Equipment",
        "Supplies",
        "Travel",
        "Marketing",
        "Insurance",
        "Maintenance",
        "Other Expense"
      ]);
    } else {
      setCategories(["Fund Transfer"]);
    }
    
    // Reset the category field when transaction type changes
    form.setValue("category", "");
  }, [transactionType, form]);
  
  // Use mutation hook for creating transactions
  const { mutate: mutateTransaction } = useAccountsMutation(
    createTransaction,
    "Transaction recorded successfully",
    "Failed to record transaction"
  );
  
  const onSubmit = async (values: TransactionFormValues) => {
    setIsSubmitting(true);
    try {
      await mutateTransaction({
        ...values,
        date: values.date.toISOString(),
        branchId: selectedBranch || "main-branch",
        referenceNumber: values.reference || `REF-${Date.now().toString().slice(-6)}`,
      });
      
      form.reset();
      onClose();
    } catch (error) {
      console.error("Error recording transaction:", error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle>Record Bank Transaction</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 py-4">
            <FormField
              control={form.control}
              name="accountId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Bank Account</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select bank account" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {isLoadingAccounts ? (
                        <SelectItem value="loading" disabled>
                          Loading accounts...
                        </SelectItem>
                      ) : bankAccounts && bankAccounts.length > 0 ? (
                        bankAccounts.map((account) => (
                          <SelectItem key={account.id} value={account.id}>
                            {account.accountName} - {account.bankName}
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="none" disabled>
                          No accounts found
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Transaction Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="income">
                          <div className="flex items-center">
                            <ArrowUpRight className="mr-2 h-4 w-4 text-green-500" />
                            Income
                          </div>
                        </SelectItem>
                        <SelectItem value="expense">
                          <div className="flex items-center">
                            <ArrowDownRight className="mr-2 h-4 w-4 text-red-500" />
                            Expense
                          </div>
                        </SelectItem>
                        <SelectItem value="transfer">Transfer</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (₹)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="Enter amount"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category.toLowerCase()}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Enter transaction details"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="reference"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Reference Number (Optional)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter reference number"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Cheque number, UPI reference, or other identifier
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Saving...' : 'Save Transaction'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
