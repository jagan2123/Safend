
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SoundSettings } from "@/components/settings/SoundSettings";
import { Volume2 } from "lucide-react";

export function SoundEffectsWidget() {
  return (
    <Card className="shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium flex items-center">
          <Volume2 className="h-4 w-4 mr-2" />
          Sound Effects
        </CardTitle>
      </CardHeader>
      <CardContent>
        <SoundSettings />
      </CardContent>
    </Card>
  );
}
