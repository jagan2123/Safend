
import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { 
  BarChart3, 
  LineChart, 
  PieChart, 
  Calendar, 
  ArrowUpRight, 
  ArrowDownRight, 
  PlusCircle, 
  ChevronRight 
} from "lucide-react";
import { DashboardWidget } from "./widgets/DashboardWidget";
import { KpiCard } from "./widgets/KpiCard";

interface ReportsDashboardProps {
  selectedModule: string | null;
}

export function ReportsDashboard({ selectedModule }: ReportsDashboardProps) {
  const [dashboardType, setDashboardType] = useState("executive");
  const [dateRange, setDateRange] = useState("last30days");
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading dashboard data
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 800);
    
    return () => clearTimeout(timer);
  }, [selectedModule, dashboardType, dateRange]);
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <Tabs 
          defaultValue="executive" 
          value={dashboardType} 
          onValueChange={setDashboardType} 
          className="w-full sm:w-auto"
        >
          <TabsList>
            <TabsTrigger value="executive">Executive</TabsTrigger>
            <TabsTrigger value="operational">Operational</TabsTrigger>
            <TabsTrigger value="financial">Financial</TabsTrigger>
            <TabsTrigger value="custom">My Dashboards</TabsTrigger>
          </TabsList>
        </Tabs>
        
        <div className="flex items-center gap-2">
          <Select defaultValue={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select date range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="yesterday">Yesterday</SelectItem>
              <SelectItem value="last7days">Last 7 Days</SelectItem>
              <SelectItem value="last30days">Last 30 Days</SelectItem>
              <SelectItem value="thisMonth">This Month</SelectItem>
              <SelectItem value="lastMonth">Last Month</SelectItem>
              <SelectItem value="thisQuarter">This Quarter</SelectItem>
              <SelectItem value="thisYear">This Year</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" size="icon">
            <Calendar className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 py-12">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="w-full h-24 animate-pulse">
              <div className="h-full bg-gray-200 dark:bg-gray-800 rounded-lg" />
            </Card>
          ))}
          
          <Card className="w-full col-span-1 md:col-span-2 h-80 animate-pulse">
            <div className="h-full bg-gray-200 dark:bg-gray-800 rounded-lg" />
          </Card>

          <Card className="w-full col-span-1 md:col-span-2 h-80 animate-pulse">
            <div className="h-full bg-gray-200 dark:bg-gray-800 rounded-lg" />
          </Card>
        </div>
      ) : (
        <div className="space-y-6">
          {/* KPI Summary Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <KpiCard 
              title="Total Revenue"
              value="₹2,452,430"
              change={12.5}
              trend="up"
              metric="vs last period"
              icon={<LineChart className="h-4 w-4 text-muted-foreground" />}
            />
            <KpiCard 
              title="Active Posts"
              value="147"
              change={2.8}
              trend="up"
              metric="vs last month"
              icon={<BarChart3 className="h-4 w-4 text-muted-foreground" />}
            />
            <KpiCard 
              title="Headcount"
              value="1,283"
              change={-3.2}
              trend="down"
              metric="vs last quarter"
              icon={<PieChart className="h-4 w-4 text-muted-foreground" />}
            />
            <KpiCard 
              title="Receivable Days"
              value="42"
              change={-5.5}
              trend="up"
              metric="vs target (45)"
              icon={<Calendar className="h-4 w-4 text-muted-foreground" />}
            />
          </div>
          
          {/* Primary Charts Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <DashboardWidget 
              title="Revenue by Branch"
              description="Monthly revenue across top 5 branches"
              type="bar"
            />
            <DashboardWidget 
              title="Headcount Trend"
              description="Monthly employee count by department"
              type="line"
            />
          </div>
          
          {/* Secondary Charts Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <DashboardWidget 
              title="Attendance Rate"
              description="Weekly attendance percentage"
              type="line"
            />
            <DashboardWidget 
              title="Receivables Aging"
              description="Outstanding invoices by age bucket"
              type="donut"
            />
            <DashboardWidget 
              title="Post Coverage"
              description="Planned vs actual deployment"
              type="bar"
            />
          </div>
          
          <div className="flex justify-center pt-4">
            <Button variant="outline" className="flex items-center gap-1">
              <PlusCircle className="h-4 w-4" />
              Add Widget
            </Button>
          </div>
          
          <Separator />
          
          {/* Module-specific Reports */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Recent Reports</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                {
                  title: "Monthly P&L Statement",
                  module: "accounts",
                  date: "May 8, 2025",
                  status: "Generated"
                },
                {
                  title: "Post Attendance Summary",
                  module: "operations",
                  date: "May 7, 2025",
                  status: "Generated"
                },
                {
                  title: "Sales Pipeline Analysis",
                  module: "sales", 
                  date: "May 6, 2025",
                  status: "Generated"
                },
                {
                  title: "Inventory Valuation Report",
                  module: "office-admin",
                  date: "May 5, 2025",
                  status: "Generated"
                },
                {
                  title: "Statutory Compliance Status",
                  module: "hr",
                  date: "May 4, 2025",
                  status: "Generated"
                },
                {
                  title: "User Activity Audit",
                  module: "control-centre",
                  date: "May 3, 2025",
                  status: "Generated"
                }
              ]
                .filter(report => !selectedModule || report.module === selectedModule)
                .map((report, index) => (
                  <Card key={index} className="cursor-pointer hover:bg-accent/5">
                    <CardHeader className="p-4">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-base">{report.title}</CardTitle>
                        <ChevronRight className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <CardDescription className="flex justify-between">
                        <span>
                          {report.module.charAt(0).toUpperCase() + report.module.slice(1).replace('-', ' ')}
                        </span>
                        <span>{report.date}</span>
                      </CardDescription>
                    </CardHeader>
                  </Card>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
