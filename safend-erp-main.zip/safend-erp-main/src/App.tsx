import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import { ThemeProvider } from "./components/ThemeProvider";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import NotFound from "./pages/NotFound";
import { SalesModule } from "./pages/sales/SalesModule";
import { OperationsModule } from "./pages/operations/OperationsModule";
import { HRModule } from "./pages/hr/HRModule";
import { AccountsModule } from "./pages/accounts/AccountsModule";
import { OfficeAdminModule } from "./pages/office-admin/OfficeAdminModule";
import { AppDataProvider } from "./contexts/AppDataContext";
import { DashboardModule } from "./pages/dashboard/DashboardModule";
import { ControlCentreModule } from "./pages/admin/ControlCentreModule";
import { BranchProvider } from "./contexts/BranchContext";

const queryClient = new QueryClient();

// Role-based route wrapper
function ProtectedRoute({ element, allowedRoles = [] }) {
  const [userRole, setUserRole] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // In a real app, this would be fetched from auth context or API
    const role = localStorage.getItem("userRole") || "admin";
    setUserRole(role);
    setLoading(false);
  }, []);
  
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-16 h-16 border-4 border-safend-red border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  
  if (!userRole || (allowedRoles.length > 0 && !allowedRoles.includes(userRole))) {
    return <Navigate to="/" replace />;
  }
  
  return element;
}

// Enhanced page transition wrapper
function PageTransition({ children }) {
  const location = useLocation();
  
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ 
          duration: 0.6, 
          ease: [0.16, 1, 0.3, 1],
          staggerChildren: 0.1
        }}
        className="w-full"
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AppDataProvider>
      <BranchProvider>
        <ThemeProvider defaultTheme="light">
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              
              <Route path="/dashboard" element={
                <PageTransition>
                  <ProtectedRoute 
                    element={<DashboardModule />} 
                    allowedRoles={["admin", "manager", "branch"]} 
                  />
                </PageTransition>
              } />
              
              {/* Redirect old reports route to new dashboard */}
              <Route path="/reports" element={<Navigate to="/dashboard" replace />} />
              
              <Route path="/control-centre" element={
                <PageTransition>
                  <ProtectedRoute 
                    element={<ControlCentreModule />} 
                    allowedRoles={["admin", "manager", "branch"]} 
                  />
                </PageTransition>
              } />
              
              {/* Redirect old routes to the new unified control centre */}
              <Route path="/control-panel" element={<Navigate to="/control-centre" replace />} />
              <Route path="/branch-management" element={<Navigate to="/control-centre" replace />} />
              
              <Route path="/sales" element={
                <PageTransition>
                  <ProtectedRoute 
                    element={<SalesModule />} 
                    allowedRoles={["admin", "manager", "sales", "branch"]} 
                  />
                </PageTransition>
              } />
              
              <Route path="/operations" element={
                <PageTransition>
                  <ProtectedRoute 
                    element={<OperationsModule />} 
                    allowedRoles={["admin", "manager", "operations", "branch"]} 
                  />
                </PageTransition>
              } />
              
              <Route path="/accounts" element={
                <PageTransition>
                  <ProtectedRoute 
                    element={<AccountsModule />} 
                    allowedRoles={["admin", "manager", "accounts", "branch"]} 
                  />
                </PageTransition>
              } />
              
              <Route path="/hr" element={
                <PageTransition>
                  <ProtectedRoute 
                    element={<HRModule />} 
                    allowedRoles={["admin", "manager", "hr"]} 
                  />
                </PageTransition>
              } />
              
              <Route path="/office-admin" element={
                <PageTransition>
                  <ProtectedRoute 
                    element={<OfficeAdminModule />} 
                    allowedRoles={["admin", "manager", "office", "branch"]} 
                  />
                </PageTransition>
              } />
              
              <Route path="*" element={
                <PageTransition>
                  <NotFound />
                </PageTransition>
              } />
            </Routes>
          </TooltipProvider>
        </ThemeProvider>
      </BranchProvider>
    </AppDataProvider>
  </QueryClientProvider>
);

export default App;
